#! /bin/sh
MDM=/bin/mdm
SAMBACONF=/var/samba/smb.conf

echo [global] > "$SAMBACONF"
echo "workgroup = WORKGROUP"  >> "$SAMBACONF"
echo "netbios name = brcm-samba_test" >> "$SAMBACONF"
echo "server string = DSL Gateway" >> "$SAMBACONF"
echo "dns proxy = no" >> "$SAMBACONF"
echo "domain master = no" >> "$SAMBACONF"
echo "local master = Yes" >> "$SAMBACONF"
echo "preferred master = Yes" >> "$SAMBACONF"
echo "os level = 35" >> "$SAMBACONF"
echo "log level = 0" >> "$SAMBACONF"
echo "log file = /dev/null" >> "$SAMBACONF"
echo "smb passwd file = /etc/samba/smbpasswd" >> "$SAMBACONF"
echo "interfaces = br0" >> "$SAMBACONF"
echo "printcap name = /dev/null" >> "$SAMBACONF"
echo "load printers = no" >> "$SAMBACONF"
echo "security = user" >> "$SAMBACONF"
echo "encrypt passwords = yes" >> "$SAMBACONF"
echo "socket options = TCP_NODELAY SO_RCVBUF=16384 SO_SNDBUF=8192" >> "$SAMBACONF"
echo "deadtime = 5" >> "$SAMBACONF"

# add subdirectory to path for OS X 10.10.1
ENTRIES=`"$MDM" getvalues InternetGatewayDevice.Services.StorageService.1.LogicalVolumeNumberOfEntries`
i=0
j=0
while [ "$j" -lt "$ENTRIES" ]
do
	i=`expr $i + 1`
	VOLUMENAME=`"$MDM" getvalues InternetGatewayDevice.Services.StorageService.1.LogicalVolume.$i.Name`
	if [ "$VOLUMENAME" != "9005" -a "$VOLUMENAME" != "null" ]; then
		j=`expr $j + 1`
		echo ["$VOLUMENAME"] >> "$SAMBACONF"
		echo "public = yes" >> "$SAMBACONF"
		echo "writable = yes" >> "$SAMBACONF"
		echo "browseable = yes" >> "$SAMBACONF"
		echo "path = /mnt/$VOLUMENAME" >> "$SAMBACONF"
	fi
	if [ $i = 50 ]; then
		break
	fi
done

killall smbd
sleep 1

if [ "$ENTRIES" != "0" ]; then
smbd -D
fi