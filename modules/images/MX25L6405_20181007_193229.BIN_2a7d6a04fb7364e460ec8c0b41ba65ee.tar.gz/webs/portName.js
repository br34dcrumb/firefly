// PLEASE NOTE THAT A SPACE BETWEEN TWO WORDS IS TAKEN AS TWO SEPERATE
// WORDS. PLEASE KEEP THIS FILE CONSISTENT.
//
// For each Linux interface name in the boardparms.c file, add
// a corresponding Linux interface name and a user-friendly name
// of its equivalent that must be displayed on the WEB UI. It is
// best if the new inteface names are added at the end.
// Make sure modifications to portName_L are consistent with
//portName_U and viceversa

//Keep #define WL_MAX_NUM_SSID here for Mbss Tag

<%ejGetOther(sysInfo, portNameInfo)%>

function getUNameByLName(name) {
   var index = 0;
   var uName   = '';
   var wlName   = '';

   // SafetyNet if someone sends a name without prefixing the
   // board ID and |, then return that name.
   if (name.indexOf('|') == -1)
      return name;
      
   /*Wlan naming: Could be a better name*/
   if (name.indexOf('wl0.') != -1) {
      wlName = name.substring(4);
      return ('wl0_Guest' + wlName);
   }
   else if (name.indexOf('wl0') != -1) {
      return 'wlan0';
   }
   else if (name.indexOf('wl1.') != -1) {
      wlName = name.substring(4);
      return ('wl1_Guest' + wlName);
   }
   else if (name.indexOf('wl1') != -1) {
      return 'wlan1';
   }

   if (name.indexOf('usb0') != -1) {
      return 'USB';
   }
   
   var lNameFull = name.split('|');
   var lName = lNameFull[1].split('.');
   if(lName.length == 1)
   {
       for (index = 0; index < portName_L.length; index++) {
          if (portName_L[index] == name) {
             uName = portName_U[index].split('|');
             return uName[1];
          }
       }
   }
   else if(lName.length == 2)
   {
       for (index = 0; index < portName_L.length; index++) {
          if (portName_L[index] == (lNameFull[0] + '|' + lName[0])) {
             uName = portName_U[index].split('|');
             if(lName[1]=='0')
                return uName[1];
             else
                return (uName[1]+'.'+lName[1]);
          }
       }
   }
   uName = name.split('|');
   return uName[1];
}

function getLNameByUName(name) {
   var index = 0;
   var brdIntf = name.split('|');
   var lName   = '';
   var uName   = '';
   var intName   = '';

   // SafetyNet if someone sends a name without prefixing the
   // board ID and |, then return that name.
   if (name.indexOf('|') == -1)
      return name;

   if (name.indexOf('wl0_Guest') != -1) {
      intName = name.substring(9);
      return ('wl0.' + intName);
   }
   if (name.indexOf('wlan0') != -1)
      return 'wl0';

   if (name.indexOf('wl1_Guest') != -1)	{
      intName = name.substring(9);
      return ('wl1.' + intName);
   }
   if (name.indexOf('wlan1') != -1)
      return 'wl1';
      
   if (name.indexOf('USB') != -1)
      return 'usb0';
   
   var uNameFull = name.split('|');
   var uName2 = uNameFull[1].split('.');
   if(uName2.length == 1)
   {
       for (index = 0; index < portName_U.length; index++) {
          uName = portName_U[index].split('|');

          if (portName_U[index] == name) {
             lName = portName_L[index].split('|');
             return lName[1];
          }
       }
   }
   else if(uName2.length == 2)
   {
       for (index = 0; index < portName_U.length; index++) {
          uName = portName_U[index].split('|');

          if (portName_U[index] == (uNameFull[0]+'|'+uName2[0])) {
             lName = portName_L[index].split('|');
             if(uName2[1] == '0')
                return lName[1];
             else
                return (lName[1]+'.'+uName2[1]);
          }
       }
   }
   lName = name.split('|');
   return lName[1];
}
