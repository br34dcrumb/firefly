﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html xmlns:v>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<title><#860#> - <#401#></title>
<link rel="stylesheet" type="text/css" href="index_style.css">
<link rel="stylesheet" type="text/css" href="form_style.css">
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/help.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script type="text/javascript" src="/validator.js"></script>
<script type="text/javascript" src="/js/jquery.js"></script>
<script>
<% wl_get_parameter(); %>
function initial(){
show_menu();
if(lantiq_support){
checkWLReady();
}
if("<% nvram_get("wl_unit"); %>" == "-1" && "<% nvram_get("wl_subunit"); %>" == "-1"){
var guestWLUnit = '<% get_parameter("gwlu"); %>';
if(guestWLUnit === "1") {
document.form.wl_unit.value = "1";
}
change_wl_unit();
}
regen_band(document.form.wl_unit);
if(!band5g_support || based_modelid == "RT-AC87U")
document.getElementById("wl_unit_field").style.display = "none";
if(smart_connect_support && '<% nvram_get("smart_connect_x"); %>' == '1' && (isSwMode("rt") || isSwMode("ap")))
document.getElementById("wl_unit_field").style.display = "none";
if(((sw_mode == 2 || sw_mode == 4) && '<% nvram_get("wl_unit"); %>' == '<% nvram_get("wlc_band"); %>') ||
(band60g_support && '<% nvram_get("wl_unit"); %>' == '3')){
for(var i=4; i>=2; i--)
document.getElementById("MainTable1").deleteRow(i);
document.getElementById("repeaterModeHint_desc").innerHTML = "<#1685#>";
document.getElementById("repeaterModeHint").style.display = "";
document.getElementById("submitBtn").style.display = "none";
}
}
function applyRule(){
if(lantiq_support && wave_ready != 1){
alert("Please wait a minute for wireless ready");
return false;
}
if(validForm()){
showLoading()
document.form.submit();
}
}
function validForm(){
if(sw_mode == 1 && IPv6_support){
var notIPv6 = false;
var notIPv4 = false;
if(!ipv6_valid(document.form.wl_radius_ipaddr))
notIPv6 = true;
if(!validator.ipAddrFinal(document.form.wl_radius_ipaddr, 'wl_radius_ipaddr', 1))
notIPv4 = true;
if(notIPv6 && notIPv4){
alert(document.form.wl_radius_ipaddr.value+" <#346#>");
document.form.wl_radius_ipaddr.value = "";
document.form.wl_radius_ipaddr.focus();
document.form.wl_radius_ipaddr.select();
return false;
}
}
else{
if(!validator.ipAddrFinal(document.form.wl_radius_ipaddr, 'wl_radius_ipaddr'))
return false;
}
if(!validator.range(document.form.wl_radius_port, 0, 65535))
return false;
if(!validator.string(document.form.wl_radius_key))
return false;
return true;
}
function done_validating(action){
refreshpage();
}
function ipv6_valid(obj){
var rangere=new RegExp("^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b)\\.){3}(\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b)\\.){3}(\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b)\\.){3}(\\b((25[0-5])|(1\\d{2})|(2[0-4]\\d)|(\\d{1,2}))\\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$", "gi");
if(rangere.test(obj.value)){
return true;
}else{
obj.focus();
obj.select();
return false;
}
}
function checkWLReady(){
$.ajax({
url: '/ajax_wl_ready.asp',
dataType: 'script',
error: function(xhr) {
setTimeout("checkWLReady();", 1000);
},
success: function(response){
if(wave_ready != 1){
$("#lantiq_ready").show();
setTimeout("checkWLReady();", 1000);
}
else{
$("#lantiq_ready").hide();
}
}
});
}
</script>
</head>
<body onload="initial();" onunLoad="return unload_body();" class="bg">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" id="ruleForm" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" name="current_page" value="Advanced_WSecurity_Content.asp">
<input type="hidden" name="next_page" value="Advanced_WSecurity_Content.asp">
<input type="hidden" name="group_id" value="">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="first_time" value="">
<input type="hidden" name="action_script" value="restart_wireless">
<input type="hidden" name="action_mode" value="apply_new">
<input type="hidden" name="action_wait" value="3">
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>">
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>">
<input type="hidden" name="wl_subunit" value="-1">
<table class="content" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
<div id="mainMenu"></div>
<div id="subMenu"></div>
</td>
<td valign="top">
<div id="tabMenu" class="submenuBlock"></div>
<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" >
<table width="760px" border="0" cellpadding="4" cellspacing="0" class="FormTitle" id="FormTitle">
<tbody>
<tr>
<td bgcolor="#4D595D" valign="top" >
<div>&nbsp;</div>
<div class="formfonttitle"><#396#> - <#401#></div>
<div style="margin:10px 0 10px 5px;" class="splitLine"></div>
<div class="formfontdesc"><#3870#></div>
<div id="lantiq_ready" style="display:none;color:#FC0;margin-left:5px;font-size:13px;">Wireless is setting...</div>
<table id="MainTable1" width="100%" border="1" align="center" cellpadding="4" cellspacing="0" class="FormTable">
<tr id="wl_unit_field">
<th><#2364#></th>
<td>
<select name="wl_unit" class="input_option" onChange="change_wl_unit();">
<option class="content_input_fd" value="0" <% nvram_match("wl_unit", "0","selected"); %>>2.4GHz</option>
<option class="content_input_fd" value="1"<% nvram_match("wl_unit", "1","selected"); %>>5GHz</option>
</select>
</td>
</tr>
<tr id="repeaterModeHint" style="display:none;">
<td id="repeaterModeHint_desc" colspan="2" style="color:#FFCC00;height:30px;" align="center"><#481#></td>
</tr>
<tr>
<th>
<a class="hintstyle" href="javascript:void(0);" onClick="openHint(2,1);">
<#3872#></a>
</th>
<td>
<input type="text" maxlength="39" class="input_32_table" name="wl_radius_ipaddr" value="<% nvram_get("wl_radius_ipaddr"); %>" onKeyPress="return validator.isIPAddr(this, event)" autocorrect="off" autocapitalize="off">
</td>
</tr>
<tr>
<th>
<a class="hintstyle" href="javascript:void(0);" onClick="openHint(2,2);">
<#3876#></a>
</th>
<td>
<input type="text" maxlength="5" class="input_6_table" name="wl_radius_port" value="<% nvram_get("wl_radius_port"); %>" onkeypress="return validator.isNumber(this,event)" autocorrect="off" autocapitalize="off"/>
</td>
</tr>
<tr>
<th >
<a class="hintstyle" href="javascript:void(0);" onClick="openHint(2,3);">
<#3874#></a>
</th>
<td>
<input type="password" maxlength="64" class="input_32_table" name="wl_radius_key" value="<% nvram_get("wl_radius_key"); %>" autocorrect="off" autocapitalize="off">
</td>
</tr>
</table>
<div id="submitBtn" class="apply_gen">
<input class="button_gen" onclick="applyRule()" type="button" value="<#203#>"/>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</form>
</tr>
</table>
</td>
<td width="10" align="center" valign="top">&nbsp;</td>
</tr>
</table>
<div id="footer"></div>
</body>
</html>

