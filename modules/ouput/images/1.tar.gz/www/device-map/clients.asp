﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<link href="/form_style.css" rel="stylesheet" type="text/css" />
<link href="/NM_style.css" rel="stylesheet" type="text/css" />
<link href="/device-map/device-map.css" rel="stylesheet" type="text/css" />
<title>device-map/clients.asp</title>
<style>
p{
font-weight: bolder;
}
.circle {
position: absolute;
width: 23px;
height: 23px;
border-radius: 50%;
background: #333;
margin-top: -77px;
margin-left: 57px;
}
.circle div{
height: 23px;
text-align: center;
margin-top: 4px;
}
.ipMethod{
background-color: #222;
font-size: 10px;
font-family: monospace;
padding: 2px 3px;
border-radius: 3px;
}
.imgUserIcon_card{
left: 17px;
}
</style>
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/js/jquery.js"></script>
<script language="JavaScript" type="text/javascript" src="/client_function.js"></script>
<script type="text/javascript" src="/help.js"></script>
<script>
if(parent.location.pathname.search("index") === -1) top.location.href = "../"+'<% networkmap_page(); %>';
var wirelessOverFlag = false;
overlib.isOut = true;
var pagesVar = {
curTab: "online",
CLIENTSPERPAGE: 7,
startIndex: 0,
endIndex: 7, /* refer to startIndex + CLIENTSPERPAGE */
startArray: [0],
resetVar: function(){
pagesVar.CLIENTSPERPAGE = 7;
pagesVar.startIndex = 0;
pagesVar.endIndex = pagesVar.startIndex + pagesVar.CLIENTSPERPAGE;
pagesVar.startArray = [0];
document.getElementById("select_wlclient_band").style.display = "none";
}
}
var clientMacUploadIcon = new Array();
var wl_nband_isWL_map = {"2.4 GHz":"1", "5 GHz":"2", "5 GHz-1":"2", "5 GHz-2":"3", "6 GHz":"4"};
function generate_wireless_band_list(){
if(wl_nband_title.length == 1) return false;
var code = '<ul>';
for(var i=0; i<wl_nband_title.length; i++){
var isWL_id = wl_nband_isWL_map[wl_nband_title[i]];
code += '<li><a onclick="switchTab_drawClientList(\'';
code += isWL_id;
code += '\')">&nbsp;&nbsp;';
code += wl_nband_title[i];
code += '&nbsp;&nbsp;(<b style="font-size:11px;" id="liWirelessNum';
code += isWL_id;
code += '">0</b>)</a></li>';
}
code += '</ul>';
document.getElementById('select_wlclient_band').innerHTML = code;
}
function initial(){
parent.hideEditBlock();
generate_wireless_band_list();
updateClientList();
setTimeout(function(){parent.httpApi.updateClientList();}, 5000);//delay to update client list, in order to avoiding the wired client disappeared
setInterval(function(){
parent.httpApi.updateClientList();
}, 1000*60*3);
reset_NM_height();
}
function drawClientList(tab){
var clientHtml = '<table width="100%" cellspacing="0" align="center"><tbody><tr><td>';
var clientHtmlTd = '';
var i = pagesVar.startIndex;
var userIconBase64 = "NoIcon";
if(typeof tab == "undefined"){
tab = pagesVar.curTab;
}
genClientList();
pagesVar.endIndex = pagesVar.startIndex + pagesVar.CLIENTSPERPAGE;
while(i < pagesVar.endIndex){
var clientObj = clientList[clientList[i]];
if(i > clientList.length-1) break;
if(tab == 'online' && !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wired' && clientObj.isWL != 0) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wireless' && clientObj.isWL == 0) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wireless1' && clientObj.isWL != 1) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wireless2' && clientObj.isWL != 2) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wireless3' && clientObj.isWL != 3) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if((tab == 'wireless4' && clientObj.isWL != 4) || !clientObj.isOnline){i++; pagesVar.endIndex++; continue;}
if(tab == 'custom' && clientObj.from != "customList"){i++; pagesVar.endIndex++; continue;}
var clientName = (clientObj.nickName == "") ? clientObj.name : clientObj.nickName;
if(clientName.toLowerCase().indexOf(document.getElementById("searchingBar").value.toLowerCase()) == -1){i++; pagesVar.endIndex++; continue;}
clientHtmlTd += '<div class="clientBg" onclick="popupCustomTable(\'' + clientObj.mac + '\');"><table width="100%" height="85px" border="0"><tr><td rowspan="3" width="85px">';
if(usericon_support) {
if(clientMacUploadIcon[clientObj.mac] == undefined) {
var clientMac = clientObj.mac.replace(/\:/g, "");
userIconBase64 = getUploadIcon(clientMac);
clientMacUploadIcon[clientObj.mac] = userIconBase64;
}
else {
userIconBase64 = clientMacUploadIcon[clientObj.mac];
}
}
var deviceTitle = (clientObj.dpiDevice == "") ? clientObj.vendor : clientObj.dpiDevice;
if(top.isIE8){
clientHtmlTd += '<div class="clientIconIE8HACK"';
clientHtmlTd += ' title="';
clientHtmlTd += deviceTitle;
clientHtmlTd += '"></div>';
}
else if(userIconBase64 != "NoIcon") {
clientHtmlTd += '<div title="'+ deviceTitle + '"">';
clientHtmlTd += '<img id="imgUserIcon_'+ i +'" class="imgUserIcon_card" src="' + userIconBase64 + '"';
clientHtmlTd += '</div>';
}
else if(clientObj.type != "0" || clientObj.vendor == "") {
clientHtmlTd += '<div class="clientIcon type';
clientHtmlTd += clientObj.type;
clientHtmlTd += '" title="';
clientHtmlTd += deviceTitle;
clientHtmlTd += '">';
if(clientObj.type == "36")
clientHtmlTd += '<div class="flash"></div>';
clientHtmlTd += '</div>';
}
else if(clientObj.vendor != "") {
var venderIconClassName = getVenderIconClassName(clientObj.vendor.toLowerCase());
if(venderIconClassName != "" && !downsize_4m_support) {
clientHtmlTd += '<div class="venderIcon ';
clientHtmlTd += venderIconClassName;
clientHtmlTd += '" title="';
clientHtmlTd += deviceTitle;
clientHtmlTd += '"></div>';
}
else {
clientHtmlTd += '<div class="clientIcon type';
clientHtmlTd += clientObj.type;
clientHtmlTd += '" title="';
clientHtmlTd += deviceTitle;
clientHtmlTd += '"></div>';
}
}
clientHtmlTd += '</td><td style="height:30px;font-size:11px;word-break:break-all;"><div>';
clientHtmlTd += clientName;
clientHtmlTd += '</div></td>';
clientHtmlTd += '<td style="width:55px">';
var MULTIFILTER_BLOCK_ALL = parent.httpApi.nvramGet(["MULTIFILTER_BLOCK_ALL"]).MULTIFILTER_BLOCK_ALL;
if(MULTIFILTER_BLOCK_ALL == "1")
clientHtmlTd += '<div class="internetBlock" title="Block Internet access" style="height:20px;width:20px;margin-right:5px;float:right;"></div>';/*untranslated*/
else{
if(!clientObj.internetState) {
clientHtmlTd += '<div class="internetBlock" title="Block Internet access" style="height:20px;width:20px;margin-right:5px;float:right;"></div>';/*untranslated*/
}
if(clientObj.internetMode == "time") {
clientHtmlTd += '<div class="internetTimeLimits" title="Time Scheduling" style="background-size:25px 20px;height:20px;width:25px;margin-right:5px;float:right;"></div>';/*untranslated*/
}
}
if(parent.sw_mode == 1){
clientHtmlTd += '</td></tr><tr><td style="height:20px;" title=\'' + ipState[clientObj.ipMethod] + '\'>';
}
else {
clientHtmlTd += '</td></tr><tr><td style="height:20px;">';
}
clientHtmlTd += (clientObj.isWebServer) ? '<a class="link" href="http://' + clientObj.ip + '" target="_blank">' + clientObj.ip + '</a>' : clientObj.ip;
clientHtmlTd += '</td><td>';
var rssi_t = 0;
var connectModeTip = "";
if(clientObj.isWL == "0") {
rssi_t = "wired";
connectModeTip = "<#3382#>";
}
else {
rssi_t = client_convRSSI(clientObj.rssi);
switch (rssi_t) {
case 1:
connectModeTip = "<#730#>: <#486#>\n";
break;
case 2:
connectModeTip = "<#730#>: <#487#>\n";
break;
case 3:
connectModeTip = "<#730#>: <#488#>\n";
break;
case 4:
connectModeTip = "<#730#>: <#489#>\n";
break;
}
if(stainfo_support) {
if(clientObj.curTx != "")
connectModeTip += "Tx Rate: " + clientObj.curTx + "\n";
if(clientObj.curRx != "")
connectModeTip += "Rx Rate: " + clientObj.curRx + "\n";
connectModeTip += "<#892#>: " + clientObj.wlConnectTime + "";
}
}
if(parent.sw_mode != 4) {
clientHtmlTd += '<div style="height:28px;width:28px;float:right;margin-right:5px;margin-bottom:-20px;">';
var radioIcon_css = "radioIcon";
if(clientObj.isGN != "" && clientObj.isGN != undefined)
radioIcon_css += " GN";
clientHtmlTd += '<div class="' + radioIcon_css + ' radio_' + rssi_t +'" title="' + connectModeTip + '"></div>';
if(clientObj.isWL != 0) {
var bandClass = (navigator.userAgent.toUpperCase().match(/CHROME\/([\d.]+)/)) ? "band_txt_chrome" : "band_txt";
clientHtmlTd += '<div class="band_block"><span class='+bandClass+'>' + isWL_map[clientObj.isWL]["text"] + '</span></div>';
}
clientHtmlTd += '</div>';
}
clientHtmlTd += '</td></tr>';
clientHtmlTd += '<tr><td colspan="2"><div style="margin-top:-15px;width:140px;" class="link" onclick="oui_query_full_vendor(\'';
clientHtmlTd += clientObj.mac;
clientHtmlTd += '\');event.cancelBubble=true;return overlib(\'';
clientHtmlTd += retOverLibStr(clientObj);
clientHtmlTd += '\');" onmouseout="nd();">';
clientHtmlTd += clientObj.mac;
clientHtmlTd += '</td></tr></table></div>';
if(clientObj.macRepeat > 1){
clientHtmlTd += '<div class="circle"><div>';
clientHtmlTd += clientObj.macRepeat;
clientHtmlTd += '</div></div>';
}
if(clientObj.wtfast && wtfast_support) {
clientHtmlTd += '<div class="boost_tag">BOOST</div>';/*untranslated*/
}
i++;
}
if(clientHtmlTd == ''){
if(networkmap_fullscan == 2)
clientHtmlTd = '<div style="color:#FC0;height:30px;text-align:center;margin-top:15px"><#1735#><img src="/images/InternetScan.gif"></div>';
else
clientHtmlTd = '<div style="color:#FC0;height:30px;text-align:center;margin-top:15px"><#2447#></div>';
}
clientHtml += clientHtmlTd;
clientHtml += '</td></tr></tbody></table>';
document.getElementById("client_list_Block").innerHTML = clientHtml;
document.getElementById("leftBtn").style.visibility = (pagesVar.startIndex == 0) ? "hidden" : "visible";
document.getElementById("rightBtn").style.visibility = (pagesVar.endIndex >= clientList.length) ? "hidden" : "visible";
if(!(isSwMode('mb') || isSwMode('ew'))) {
document.getElementById("tabWired").style.display = (totalClientNum.wired == 0) ? "none" : "";
document.getElementById("tabWiredNum").innerHTML = totalClientNum.wired;
if(document.getElementById("tabWired").offsetWidth > 150 ||
(document.getElementById("tabOnline").offsetWidth+document.getElementById("tabWired").offsetWidth+document.getElementById("tabWireless").offsetWidth) > 300){
var wired_span = document.getElementById("tabWiredSpan").innerHTML;
var Modified_wired_term = wired_span.replace("<#3382#>", "<#3770#>");
document.getElementById("tabWiredSpan").innerHTML = Modified_wired_term;
}
}
if(!(isSwMode('mb') || isSwMode('ew'))) {
document.getElementById("tabWireless").style.display = (totalClientNum.wireless == 0) ? "none" : "";
document.getElementById("tabWirelessNum").innerHTML = totalClientNum.wireless;
if(document.getElementById("tabWireless").offsetWidth > 150 ||
(document.getElementById("tabOnline").offsetWidth+document.getElementById("tabWired").offsetWidth+document.getElementById("tabWireless").offsetWidth) > 300){
var wireless_span = document.getElementById("tabWirelessSpan").innerHTML;
var Modified_wireless_term = wireless_span.replace("<#3383#>", "WiFi");
document.getElementById("tabWirelessSpan").innerHTML = Modified_wireless_term;
}
}
if(totalClientNum.wireless == 0)
wirelessOverFlag = false;
if(wl_nband_title.length > 1){
for(var i=0; i<wl_nband_title.length; i++){
var isWL_id = wl_nband_isWL_map[wl_nband_title[i]];
document.getElementById("liWirelessNum" + isWL_id).innerHTML = totalClientNum.wireless_ifnames[parseInt(isWL_id)-1];
}
}
if(typeof tab.split("wireless")[1] == 'undefined' || tab.split("wireless")[1] == '' || tab.split("wireless")[1] == 'NaN'){
if(!wirelessOverFlag)
document.getElementById("select_wlclient_band").style.display = "none";
document.getElementById("searchingBar").placeholder = 'Search';
}
else{
document.getElementById("searchingBar").placeholder = '[' + wl_nband_title[tab.split("wireless")[1]] + '](' + totalClientNum.wireless_ifnames[tab.split("wireless")[1]] + ')';
}
if(pagesVar.curTab != tab){
document.getElementById("client_list_Block").style.display = 'none';
$("#client_list_Block").fadeIn(300);
pagesVar.curTab = tab;
}
$(".circle").mouseover(function(){
return overlib(this.firstChild.innerHTML + " clients are connecting to <% nvram_get("productid"); %> through this device.");
});
$(".circle").mouseout(function(){
nd();
});
}
function updatePagesVar(direction){
if(typeof direction != "undefined"){
if(direction == '-'){
pagesVar.startArray.length--;
pagesVar.startIndex = pagesVar.startArray.slice(-1)[0];
pagesVar.endIndex = pagesVar.startIndex + pagesVar.CLIENTSPERPAGE;
}
else if(direction == '+'){
pagesVar.startIndex = pagesVar.endIndex;
pagesVar.endIndex = pagesVar.startIndex + pagesVar.CLIENTSPERPAGE;
pagesVar.startArray.push(pagesVar.startIndex);
}
pagesVar.startIndex = (pagesVar.startIndex < 0) ? 0 : pagesVar.startIndex;
pagesVar.endIndex = (pagesVar.endIndex > clientList.length) ? clientList.length : pagesVar.endIndex;
pagesVar.endIndex = (pagesVar.endIndex < pagesVar.CLIENTSPERPAGE) ? pagesVar.CLIENTSPERPAGE : pagesVar.endIndex;
}
drawClientList(pagesVar.curTab);
}
function retOverLibStr(client){
var overlibStr = "<p><#381#>:</p>" + client.mac.toUpperCase();
if(client.ssid)
overlibStr += "<p>SSID:</p>" + client.ssid.replace(/"/g, '&quot;');
if(client.isLogin)
overlibStr += "<p>Logged In User:</p>YES";
if(client.isPrinter)
overlibStr += "<p><#1737#></p>YES";
if(client.isITunes)
overlibStr += "<p><#1736#></p>YES";
if(client.isWL > 0){
overlibStr += "<p><#3869#>:</p>" + isWL_map[client.isWL]["text"].replace("G", " GHz") + " (" + client.rssi + " dBm)";
if(stainfo_support) {
overlibStr += "<p>Tx Rate:</p>" + ((client.curTx != "") ? client.curTx : "-");
overlibStr += "<p>Rx Rate:</p>" + ((client.curRx != "") ? client.curRx : "-");
overlibStr += "<p><#892#>:</p>" + client.wlConnectTime;
}
}
return overlibStr;
}
function oui_query_full_vendor(mac){
if(clientList[mac].vendor != "") {
setTimeout(function(){
var overlibStrTmp = retOverLibStr(clientList[mac]);
overlibStrTmp += "<p><span>.....................................</span></p><p style='margin-top:5px'><#2682#> :</p>";
overlibStrTmp += clientList[mac].vendor;
return overlib(overlibStrTmp);
}, 1);
}
else {
if('<% nvram_get("x_Setting"); %>' == '1' && wanConnectStatus && clientList[mac].internetState) {
var queryStr = mac.replace(/\:/g, "").splice(6,6,"");
var overlibStrTmp = retOverLibStr(clientList[mac]);
$.getJSON("https://nw-dlcdnet.asus.com/plugin/js/ouiDB.json", function(data){
if(data != "" && data[queryStr] != undefined){
if(overlib.isOut) return nd();
var vendor_name = data[queryStr].trim();
overlibStrTmp += "<p><span>.....................................</span></p><p style='margin-top:5px'><#2682#> :</p>";
overlibStrTmp += vendor_name;
return overlib(overlibStrTmp);
}
});
}
}
}
function popupCustomTable(mac){
parent.popupEditBlock(clientList[mac]);
}
function updateClientList(e){
$.ajax({
url: '/update_clients.asp',
dataType: 'script',
error: function(xhr) {
setTimeout("updateClientList();", 1000);
},
success: function(response){
document.getElementById("loadingIcon").style.visibility = (networkmap_fullscan == 1 && parent.manualUpdate) ? "visible" : "hidden";
if(isJsonChanged(originData, originDataTmp) || originData.fromNetworkmapd == ""){
drawClientList();
parent.show_client_status(totalClientNum.online);
}
if(networkmap_fullscan == 0) parent.manualUpdate = false;
setTimeout("updateClientList();", 3000);
}
});
}
</script>
</head>
<body class="statusbody" onload="initial();">
<iframe name="applyFrame" id="applyFrame" src="" width="0" height="0" frameborder="0" scrolling="no"></iframe>
<form method="post" name="form" id="refreshForm" action="/apply.cgi" target="applyFrame">
<input type="hidden" name="action_mode" value="refresh_networkmap">
<input type="hidden" name="action_script" value="">
<input type="hidden" name="action_wait" value="5">
<input type="hidden" name="current_page" value="device-map/clients.asp">
<input type="hidden" name="next_page" value="device-map/clients.asp">
</form>
<table border="0" cellpadding="0" cellspacing="0" style="width:100%">
<tr>
<td>
<table width="100px" border="0" align="left" style="margin-left:8px;" cellpadding="0" cellspacing="0">
<td>
<div id="tabOnline" class="tabclick_NW" align="center">
<span id="tabOnlineSpan">
<#1562#>
</span>
</div>
<script>
document.getElementById('tabOnline').onclick = function(){
pagesVar.resetVar();
drawClientList('online');
document.getElementById('tabOnline').className = 'tabclick_NW';
document.getElementById('tabWired').className = 'tab_NW';
document.getElementById('tabWireless').className = 'tab_NW';
document.getElementById('tabCustom').className = 'tab_NW';
}
</script>
</td>
<td>
<div id="tabWired" class="tab_NW" align="center" style="display:none">
<span id="tabWiredSpan">
<#3382#>&nbsp;(<b style="font-size:10px;" id="tabWiredNum">0</b>)
</span>
</div>
<script>
document.getElementById('tabWired').onclick = function(){
pagesVar.resetVar();
drawClientList('wired');
document.getElementById('tabOnline').className = 'tab_NW';
document.getElementById('tabWired').className = 'tabclick_NW';
document.getElementById('tabWireless').className = 'tab_NW';
document.getElementById('tabCustom').className = 'tab_NW';
}
</script>
</td>
<td>
<div id="tabWireless" class="tab_NW" align="center" style="display:none;position:relative;min-width:85px;">
<span id="tabWirelessSpan">
<#3383#>&nbsp;(<b style="font-size:10px;" id="tabWirelessNum">0</b>)
</span>
<nav class="nav" style="position:absolute;" id="select_wlclient_band"></nav>
</div>
<script>
function switchTab_drawClientList(wband){
pagesVar.resetVar();
drawClientList('wireless' + wband);
document.getElementById('tabOnline').className = 'tab_NW';
document.getElementById('tabWired').className = 'tab_NW';
document.getElementById('tabWireless').className = 'tabclick_NW';
document.getElementById('tabCustom').className = 'tab_NW';
}
$('#tabWirelessSpan').click(function(){
switchTab_drawClientList('');
});
$('#tabWireless').mouseenter(function(){
if(wl_nband_title.length > 0){
$("#select_wlclient_band").slideDown("fast", function(){});
wirelessOverFlag = true;
}
});
$('#tabWireless').mouseleave(function(){
$("#select_wlclient_band").css({"display": "none"});
wirelessOverFlag = false;
});
</script>
</td>
<td>
<div id="tabCustom" class="tab_NW" align="center" style="display:none">
<span>
History (<b style="font-size:10px;" id="tabCustomNum">0</b>)
</span>
</div>
<script>
document.getElementById('tabCustom').onclick = function(){
pagesVar.resetVar();
drawClientList('custom');
document.getElementById('tabOnline').className = 'tab_NW';
document.getElementById('tabWired').className = 'tab_NW';
document.getElementById('tabWireless').className = 'tab_NW';
document.getElementById('tabCustom').className = 'tabclick_NW';
}
</script>
</td>
<td>
</td>
</table>
</td>
</tr>
<tr>
<td>
<table width="95%" border="0" align="center" cellpadding="4" cellspacing="0" class="list_bg">
<tr>
<td style="padding:3px 3px 5px 5px;">
<input type="text" placeholder="Search" id="searchingBar" class="input_25_table" style="width:96%;margin-top:3px;margin-bottom:3px" maxlength="" value="" autocorrect="off" autocapitalize="off">
<script>
document.getElementById('searchingBar').onkeyup = function(){
pagesVar.resetVar();
drawClientList();
}
</script>
<div id="client_list_Block"></div>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br/>
<img height="25" id="leftBtn" onclick="updatePagesVar('-');" style="cursor:pointer;margin-left:10px;" src="/images/arrow-left.png">
<input type="button" id="refresh_list" class="button_gen" value="<#1689#>" style="margin-left:70px;">
<script>
document.getElementById('refresh_list').onclick = function(){
parent.manualUpdate = true;
document.form.submit();
}
if(parent.document.stopNetworkmapd.networkmap_enable.value == 0 && disnwmd_support) $("#refresh_list").hide()
</script>
<img src="/images/InternetScan.gif" id="loadingIcon" style="visibility:hidden">
<img height="25" id="rightBtn" onclick="updatePagesVar('+');" style="cursor:pointer;margin-left:25px;" src="/images/arrow-right.png">
</body>
</html>

