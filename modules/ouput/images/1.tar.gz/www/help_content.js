﻿var productid = '<#861#>';
helpcontent[0] = new Array("",
"<#3926#>",
"<#3966#>",
"<#3889#>",
"<#4001#>",
"<#3879#>",
"<#3946#>",
"<#4016#>",
"<#4012#>",
"<#3941#>",
"<#3936#>",
"<#4027#><#2517#>", //11
"<#870#>",
"<#871#>",
"<#3891#><br/><#3943#>",
"<#3915#>",
"<#3928#>",
"",
"WEP-64bits: <#870#><br/>WEP-128bits: <#871#>",
"<#870#><br/><#871#>",
"<#870#><br/><#871#>",
"<#870#><br/><#871#>", //21
'<div><#683#></div><br/><img src="/images/qis/select_wireless.jpg">',
'<div><#684#></div><br/><img width="350px" src="/images/qis/security_key.png">',
"",
"<#893#>",
"<#890#>",
"Smart Connect is the feature which could automatically steer clients to the most appropriate band (2.4GHz, 5GHz-1 and 5GHz-2)." /*untranslated*/
);
if ("<% nvram_get("wl2_band"); %>".length == 0)
helpcontent[0][27] = "Smart Connect is the feature which could automatically steer clients to the most appropriate band (2.4GHz and 5GHz)."; /*untranslated*/
helpcontent[1] = new Array("",
"<#3954#>",
"<#3889#>",
"<#3971#>",
"<#4002#>",
"<#4003#>",
"<#4004#>",
"<#4005#>");
helpcontent[2] = new Array("",
"<#3871#>",
"<#3875#>",
"<#3873#>");
helpcontent[3] = new Array("",
"<#4018#>",
"<#4020#><p><a href='/Main_LogStatus_Content.asp' target='_blank'><#289#><#1539#></a></p>",
"<#4022#><p><a href='/Main_LogStatus_Content.asp' target='_blank'><#289#><#1539#></a></p>",
"<#3978#>",
"<#3994#>",
"<#3895#>",
"<#3921#>",
"<#3893#>",
"<#3985#>",
"<#4031#>",
"<#3977#>",
"<#3964#>",
"<#4038#>",
"<#4041#>",
"<#4010#>",
"<#4014#>",
"<#3959#>",
"<#3975#>",
"[n Only]: <#3988#>",
"<#4059#>",
"<#3981#>", //21
"<#3990#>",
"<#4033#>",
"<#3984#> (It's also called [Explicit Beamforming].)", /* untranslated */
"<#3993#> (It's also called [Implicit Beamforming].)", /* untranslated */
"<#3953#>",
"<#3951#>",
"<#4037#> <#3963#>",
"<#4025#>",
"<#3129#>",
"<#4030#>", //31
"<#3962#>",
"<#3963#>",
"<#3969#>"
);
helpcontent[4] = new Array("",
"<#363#>",
"<#365#>",
"<#2615#>");
helpcontent[5] = new Array("",
"<#2546#>",
"<#2556#><#2557#>",
"<#2569#>",
"<#2567#>",
"<#2559#>",
"<#2619#>",
"<#2616#>",
"<#2634#>",
"<#2561#>",
"<#364#>",
"<#2565#>", //11
"<#2566#>",
"<#2600#>",
"<#3114#>",
"<#3115#>",
"Enable Fast Leave",
"<#2592#>",
"<#1722#>");
helpcontent[6] = new Array("",
"<#3075#>",
"<#3076#>",
"<#3077#>",
"<#3078#>",
"<#3079#>",
"<#3080#>",
"<#3100#>");
helpcontent[7] = new Array("",
"<#301#>",
"<#323#>",
"<#321#>",
"<#2996#>",
"<#2995#>",
"<#2993#>",
"<#3013#>",
"<#3011#>",
"<#3019#>",
"<#2997#>",
"<#3015#>", //11
"<#319#>",
"<#305#>",
"<#307#>",
"<#1532#>",
"<#502#>",
"<#3017#>",
"<#2999#>",
"<#1531#>",
"<#2420#>",
"<#2639#>", //21
"<#2346#>",
"<#2435#>",
"<#2430#>",
"<#2428#>",
"<#2429#>",
"<#614#>",
"<#2502#>",
"<#2988#>",
"<#2989#>", //30
"<#3003#>", //31
"<#3006#>",
"<#3008#>",
"<#3010#>",
"<#3801#>",
"<#3789#>",
"<#3793#>",
"<#3795#>",
"<#3797#>",
"<#3799#>",
"<#3787#>", //41
"<#3785#>",
"<#3804#>",
"<#3806#>",
"<#3808#>",
"<#3810#>"
);
helpcontent[8] = new Array("",
"<#2109#>",
"<#2115#> Notice that this option will control http and https port access from WAN interface.", /* untranslated */
"<#2118#>",
"<#2111#>",
"<#2113#>",
"<#2066#>",
"<#2064#>");
helpcontent[9] = new Array("",
"<#2099#>",
"<#2101#>",
"<#2079#>");
helpcontent[10] = new Array("",
"<#2075#>",
"<#2077#>",
"<#2079#>",
"<#2084#>",
"<#2082#>");
helpcontent[11] = new Array("",
"<#2623#>",
"<#2627#>",
"<#2620#>",
"<#608#> <#368#>",
"<#608#> <#275#>",
"<#1895#>",
"<#2631#>",
"<#2633#>",
"For destination IP address, you can:<br/>(a) enter a specific IP address, such as \"192.168.1.2\"<br/>(b) enter IP addresses within one subnet or within the same IP pool, such as \"192.168.1.0/24\"", /* untranslated */
"<#769#>",
"<#3551#>",
"If there is no client connection for more than 1 minute, the PLC will enter sleep mode (power saving). The PLC will not wake up until the client connects. (It takes about ten seconds to wake up the PLC)", /* untranslated */
"Enable Login CAPTCHA is to ensure only human users to pass through and prevent brute force login attack.", /* untranslated */
"<#2154#>");
helpcontent[12] = new Array("",
"<#2248#>",
"<#3029#>",
"<#3031#>",
"<#3033#>");
helpcontent[13] = new Array("",
"<#4043#>",
"<#4049#>",
"<#4051#>",
"<#3973#>",
"<#4047#>");
helpcontent[14] = new Array("",
"<#3529#>",
"");
helpcontent[15] = new Array("",
"", /*<#986#>*/
"<#993#><p><a href='../Advanced_AiDisk_ftp.asp' target='_parent' hidefocus='true'><#2811#></a></p><!--span style='color:red'><#994#></span-->",
"<#996#>",
"<#998#>");
helpcontent[16] = new Array("",
"<#1935#><p><#1936#> <a href='/QoS_EZQoS.asp'><#1524#></a></p>");
helpcontent[17] = new Array("",
"<#2525#>",
"<#2526#>",
"<#2314#>",
"<#2508#>",
"<#2509#>",
"<#2510#>",
"<#3208#>",
"<#3206#>",
"<#3198#>");
helpcontent[18] = new Array("",
"<#2096#>",
"<#2965#>",
"<#2413#>",
"<#2965#>",
"<#3575#>",
"<#3265#>");
helpcontent[19] = new Array("",
"<#3179#>",
"<#3185#>",
"<#3189#>",
"<#3180#>"
);
helpcontent[20] = new Array("",
'<#1919#>',
"<#2702#>",
"<#2686#>",
"<#1533#>",
"<#1931#>",
"<#1933#>",
"<#163#>");
helpcontent[21] = new Array("",
"<#2332#>",
"<#2337#>",
"<#2338#>",
"HSDPA<#3013#>",
"HSDPA<#3011#>",
"<#305#>",
"<#307#>",
"<#2333#>",
"<#2322#>",
"<#2325#>",
"<#2342#>",
"<#2335#>",
"<#2341#>");
helpcontent[22] = new Array("",
"<#456#>",
"<#456#>",
"<#449#>");
helpcontent[23] = new Array("",
"",
"",
"<#3290#>",
"<#3292#>",
"<#3291#>");
helpcontent[24] = new Array("",
"<#305#>", //7,13
"<#307#>", //7,14
"<#319#>",//7,12
"<#321#>",//7,3
"<#363#>", //4,1
"<#365#>", //4,2
"<#368#>", //11,4
"<#614#>", //7,27
"<#683#>", //0,22
"<#684#>"); //0,23
helpcontent[25] = new Array("",
"<#1834#>",
"<#1833#>",
"<#1820#>",
"This item allows you to tweak the target SNR Margin of VDSL. For instance with a downstream SNR Margin at 8dB, you could set to 7dB or lower value to maximize the downstream performance, 2dB (Max.performance) but please note that the lower the value, DSL modem router will be weaker to defend the line noise, thus sync loss might occur, so please adjust with proper value. However, if your VDSL connection is unstable or not able to establish a connection, for this case then set to a higher value such as 9dB ~ 30dB.",
"This item allows you to tweak the Tx Power of VDSL. Reduce Tx Power(-1 dB ~ -7 dB) would increase the downstream performance(reduce more Tx Power leads to higher downstream data rate), but will impact upstream and vice versa.",
"This item configures Rx AGC(Auto Gain Control) GAIN for VDSL, if tweak the Stability Adjustment (VDSL) setting still could not get desired downstream speed, then could try to set Rx AGC GAIN Adjustment to High Performance mode. However if your VDSL connection is unstable and has some CRC then could set to Stable mode.",
"This item allows you to control whether to Enable/Disable UPBO(Upstream Power Back Off) for VDSL. DSLAM could use UPBO to reduce the Tx Power of your xDSL modem router, in some cases abnormal UPBO control from DSLAM could leads to sync up issue(such as not enough Tx Power to sync with minimum rate). Thus with this feature now you could disable UPBO and will not get affected by DSLAM setting.",
"This item configures Profile to be used for VDSL connection, default is 30a multi mode. However in order to work around the non-standard 30a multi mode VDSL DSLAM sync issue, which deployed by some of Germany ISP, set to 17a multi mode might be needed in order for the VDSL line to sync up. For users of other countries, there is no need to change this setting.",
"Apply special settings for specific country. With this option, the Stability Adjustment for ADSL is properly set according to the selected country.",
"This item allows system to monitor the DSL line, designed to maintain stability of the line. Based on current line condition necessary changes will be adopted.", //10
"This feature allows system to capture diagnostic DSL debug log in the background, duration depends on the \"Diagnostic debug log capture duration\" option, after capture completed debug log would be transmitted automatically to ASUS Support Team for analysis.",
"The G.INP stands for Impulse Noise Protection. It works on ADSL2, ADSL2+, and VDSL2 only. It is enabled to provide enhanced protection against impulse noise or to increase the efficiency of providing impulse noise protection. If your DSLAM does not support it, please disable it.",
"This item configures Rx AGC(Auto Gain Control) GAIN for ADSL, if tweak the Stability Adjustment (ADSL) setting still could not get desired downstream speed, then could try to set Rx AGC GAIN Adjustment to High Performance mode. However if your ADSL connection is unstable and has some CRC then could set to Stable mode.",
"This item supports G.vector. With G.vector crosstalk among the signals in the same cable could be canceled, such as far-end crosstalk (FEXT). Which would significantly improve Signal-to-Noise Ratio (SNR) that leads to higher achievable bit rates. However CO must deploy Vectored VDSL2 DSLAM in order for this feature to work. If you find it doesn't work well or you know the G.vector of your ISP is non-standard, please enable both of this option and Non-standard G.vector.",
"This item supports Non-standard G.vector for specific countries. Please note that if your G.vector is standard, please do not enable this option for optimized performance.",
"This command is helpful for some impulse noise environment to enhance line stability.",
"Enhancing the detection of impulse noise may improve certain lines with frequent noise fluctuations. If your DSL line supports G.INP and your connection is often unstable, then you can try to enable it.",
"This item allows you to tweak the target SNR Margin. You could set to negative value to maximize the downstream performance. But please note that the lower the value, DSL modem router will be weaker to defend the line noise. Sync loss might occur. So please adjust with proper value. However, if your xDSL connection is unstable or not able to establish a connection, setting to a postive value.",
""
);
helpcontent[26] = new Array("",
"<#1867#>",
"<#1876#>",
"<#1875#>",
"<#1866#>",
"<#1877#>",
"<#1851#>");
helpcontent[27] = new Array("",
"<#4087#>: <#4088#><br>" +
"<#4089#>: <#4090#><br>" +
"<#4091#>: <#4092#>");
if('<% nvram_default_get("lan_ipaddr"); %>' != "192.168.1.1"){
helpcontent[4][1] = "<#363#>".replace("192.168.1.1", '<% nvram_default_get("lan_ipaddr"); %>');
helpcontent[24][5] = "<#363#>".replace("192.168.1.1", '<% nvram_default_get("lan_ipaddr"); %>');
}
helpcontent[28] = new Array("");
helpcontent[29] = new Array("",
"<#2826#>",
"<#2815#>");
helpcontent[30] = new Array("",
"Send alert before monthly alert is reached",/*untranslated*/
"Cut-off internet if monthly limit is reached");/*untranslated*/
helpcontent[31] = new Array("",
"The WiFi and authentication session will be disconnected if user does not process within the defined Idle time.",/*untranslated*/
"The WiFi and Internet connection will be disconnected after a specified period of inactivity.",/*untranslated*/
"The WiFi and Internet connection will be disconnected if the defined Internet session time expired.",/*untranslated*/
"The NAS ID is string on RADIUS attribute 32, which allows captive portal to send authentication request to RADIUS server for applying different policy of user group.Then, the RADIUS server can send a customized authentication response base on the received NAS ID for the captive portal. To enable the features, you must configure NAS ID policy on RADIUS server correspondingly.",/*untranslated*/
"Enter a whitelist URL, also known as walled garden.\nNote: Guest user can fetch the whitelist web content under the domain name without any authentication."/*untranslated*/
);
helpcontent[32] = new Array("",
"<#4234#>",
"Enable this option allows VPN clients to access the subnet of your LAN",/*untranslated*/
"Enable this option allows VPN clients use the Internet from your router instead of the one at their location.",/*untranslated*/
"Virtual network device type. TUN devices encapsulate IPv4 or IPv6 (OSI Layer 3) while TAP devices encapsulate Ethernet 802.3 (OSI Layer 2).",/*untranslated*/
"Choose the communicating protocol with remote host.",/*untranslated*/
"Set the port number to bind. The current default of 1194 represents the official IANA port number assignment for OpenVPN.",/*untranslated*/
"<b>TLS</b>: OpenVPN runs in server mode and SSL/TLS authentication will be used;<br> <b>Static Key</b>: OpenVPN runs in P2P mode.",/*untranslated*/
"The bits size of automatically generated certificate.",/*untranslated*/
"Use username/password only allows client connect to server without certification and authentication by username/password. Be aware that using this directive is less secure than requiring certificates.",/*untranslated*/
"Add an additional layer of HMAC authentication on top of the TLS control channel to protect against DoS attacks. An OpenVPN static key will be used.",/*untranslated*/ //10
"This directive will set up an OpenVPN server which will allocate addresses to clients out of the given network/netmask. The server itself will take the \".1\" address of the given network for use as the server-side endpoint of the local TUN/TAP interface.",/*untranslated*/
"The IP address of the local and remote VPN endpoint in p2p mode.",/*untranslated*/
"<b><#194#></b>: Use LAN DHCP server to allocate IP address;<br> <b><#193#></b>: Allocate IP address from the Address Pool",/*untranslated*/
"The first address and the last address in the pool to be assigned to clients.",/*untranslated*/
"Response the DNS query from clients.",/*untranslated*/
"In server mode, provide DNS information to clients.",/*untranslated*/
"The cipher algorithm to encrypt packets in transmission. AES-128-CBC is recommendation.",/*untranslated*/
"Use fast LZO compression. It may add up to 1 byte per packet for incompressible data.",/*untranslated*/
"This option can be used on both the client and server, and whichever uses the lower value will be the one to trigger the renegotiation. Renegotiate data channel key after n seconds (default=3600), 0 to disable.",/*untranslated*/
"When this option is enabled, each client can view the other clients which are currently connected. Otherwise, each client will only see the server.",/*untranslated*/ //20
"Only the client in the \"Allowed Clients\" table could be authenticated.",/*untranslated*/
"The Username / Common Name(CN) of client certificate.<br> If setting authenticated by username / password only, this field should be the username in the \"Username and Password\" table.",/*untranslated*/
"The Network Address of a subnet to generate an internal route to a specific client. This specific client should own this subnet.",/*untranslated*/
"The Network Mask of a subnet to generate an internal route to a specific client. This specific client should own this subnet.",/*untranslated*/
" If you would like other clients to be able to this specific client's subnet, choose Yes and Enable \"Allow Client <-> Client\".",/*untranslated*/
"The message digest algorithm which is used to authenticate packets with HMAC. HMAC usually adds 16 or 20 bytes per packet.",/*untranslated*/
"When you would restore or replace router, you can keep original certification of OpenVPN server via \"Export Current Certification\".",/*untranslated*/
"You can shift original certification of OpenVPN server from your other one or the old ASUS router, rather than create a new one and ask all clients to setup OpenVPN profile again."/*untranslated*/
);
helpcontent[33] = new Array("",
"<#3705#>",
"<#3723#>"
);
helpcontent[34] = new Array("",
"This feature allows system to capture diagnostic System debug log in the background, duration depends on the Diagnostic debug log capture duration option, depends on the option selected, system might transmit single debug log automatically to ASUS Support Team for analysis after capture completed or transmit multiple debug logs over a period of time. Click on the yellow System icon could cancel the debug log capture.",/*untranslated*/
"<#1944#>",
"<#2022#>"
);
helpcontent[35] = new Array("",
"<#2781#>",
"<#2796#>",
"<#2793#>",
"<#2779#>");

