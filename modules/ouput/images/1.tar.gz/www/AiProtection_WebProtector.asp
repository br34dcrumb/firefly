﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html xmlns:v>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<title><#860#> - <#1227#></title>
<link rel="stylesheet" type="text/css" href="index_style.css">
<link rel="stylesheet" type="text/css" href="form_style.css">
<link rel="stylesheet" type="text/css" href="device-map/device-map.css">
<script type="text/javascript" src="state.js"></script>
<script type="text/javascript" src="popup.js"></script>
<script type="text/javascript" src="general.js"></script>
<script type="text/javascript" src="help.js"></script>
<script type="text/javascript" src="validator.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="form.js"></script>
<script type="text/javascript" src="switcherplugin/jquery.iphone-switch.js"></script>
<script type="text/javascript" src="client_function.js"></script>
<script type="text/javascript" src="/js/httpApi.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/asus_eula.js"></script>
<style>
*{
box-sizing: content-box;
}
#switch_menu{
text-align:right
}
#switch_menu span{
border-radius:4px;
font-size:16px;
padding:3px;
}
/*#switch_menu span:hover{
box-shadow:0px 0px 5px 3px white;
background-color:#97CBFF;
}*/
.click:hover{
box-shadow:0px 0px 5px 3px white;
background-color:#97CBFF;
}
.clicked{
background-color:#2894FF;
box-shadow:0px 0px 5px 3px white;
}
.click{
background:#8E8E8E;
}
</style>
<script>
var apps_filter = "<% nvram_get("wrs_rulelist"); %>".replace(/&#62/g, ">").replace(/&#60/g, "<");
var wrs_filter = "<% nvram_get("wrs_rulelist"); %>".replace(/&#62/g, ">").replace(/&#60/g, "<");
var wrs_app_filter = "<% nvram_get("wrs_app_rulelist"); %>".replace(/&#62/g, ">").replace(/&#60/g, "<");
var wrs_id_array = [["1,2,3,4,5,6,8", "9,10,14,15,16,25,26", "11"],
["24", "51", "53,89", "42", ""],
["56,70,71", "57"],
["", "69", "23"]];
var apps_id_array = [["22", "", ""],
["24", "0,6,15", "", "", "21"],
["3", "1"],
["8", "4", ""]];
var curState = '<% nvram_get("wrs_enable"); %>';
var faq_href = "https://nw-dlcdnet.asus.com/support/forward.html?model=&type=Faq&lang="+ui_lang+"&kw=&num=140";
function initial(){
show_menu();
document.getElementById("faq").href=faq_href;
translate_category_id();
genMain_table();
if('<% nvram_get("wrs_enable"); %>' == 1)
showhide("list_table",1);
else
showhide("list_table",0);
showDropdownClientList('setClientIP', 'mac', 'all', 'ClientList_Block_PC', 'pull_arrow', 'all');
if(!ASUS_EULA.status("tm"))
ASUS_EULA.config(eula_confirm, cancel);
}
function pullLANIPList(obj){
var element = document.getElementById('ClientList_Block_PC');
var isMenuopen = element.offsetWidth > 0 || element.offsetHeight > 0;
if(isMenuopen == 0){
obj.src = "/images/arrow-top.gif"
element.style.display = 'block';
document.form.PC_devicename.focus();
}
else
hideClients_Block();
}
function hideClients_Block(){
document.getElementById("pull_arrow").src = "/images/arrow-down.gif";
document.getElementById('ClientList_Block_PC').style.display='none';
}
function setClientIP(macaddr){
document.form.PC_devicename.value = macaddr;
hideClients_Block();
}
var previous_obj = "";
function show_subCategory(obj){
var sub_category_state = obj.className
var sub_category = $(obj).siblings()[1];
var category_desc = $(obj).siblings()[2];
if(sub_category_state == "closed"){
sub_category.style.display = "";
if(category_desc)
category_desc.style.display = "none";
obj.setAttribute("class", "opened");
if(previous_obj != ""){ //Hide another category
$(previous_obj).siblings()[1].style.display = "none";
if($(previous_obj).siblings()[2])
$(previous_obj).siblings()[2].style.display = "";
previous_obj.setAttribute("class", "closed");
}
previous_obj = obj;
}
else{
sub_category.style.display = "none";
if($(previous_obj).siblings()[2])
$(previous_obj).siblings()[2].style.display = "";
obj.setAttribute("class", "closed");
if($(previous_obj).siblings()[1] = sub_category){ //To handle open, close the same category
$(previous_obj).siblings()[1] = "";
previous_obj = "";
}
}
}
function set_category(obj, flag){
var checked_flag = 0;
if(flag == 0){
var children_length = $(obj).siblings()[1].children.length;
if(obj.checked == true){
for(var i=0; i<children_length; i++){
$(obj).siblings()[1].children[i].children[1].checked = true;
}
}
else{
for(var i=0; i<children_length; i++){
$(obj).siblings()[1].children[i].children[1].checked = false;
}
}
}
else{
var parent_category = $(obj.parentNode.parentNode).siblings()[1];
var sibling = $(obj.parentNode).siblings();
var sibling_length = $(obj.parentNode).siblings().length;
if(obj.checked == true){
if(parent_category.checked != true)
parent_category.checked = true;
}
else{
for(var i=0; i<sibling_length; i++){
if(sibling[i].children[1].checked == true){
checked_flag = 1;
}
}
if(checked_flag == 0){
parent_category.checked =false;
}
}
}
}
function deleteRow_main(obj){
var item_index = obj.parentNode.parentNode.rowIndex;
document.getElementById(obj.parentNode.parentNode.parentNode.parentNode.id).deleteRow(item_index);
var target_mac = obj.parentNode.parentNode.children[1].title;
var apps_filter_row = apps_filter.split("<");
var apps_filter_temp = "";
for(var i=0;i<apps_filter_row.length;i++){
var apps_filter_col = apps_filter_row[i].split(">");
if(apps_filter_col[1] != target_mac){
if(apps_filter_temp == ""){
apps_filter_temp += apps_filter_row[i];
}
else{
apps_filter_temp += "<" + apps_filter_row[i];
}
}
}
apps_filter = apps_filter_temp;
genMain_table();
}
function check_macaddr(obj,flag){ //control hint of input mac address
if(flag == 1){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<#364#>";
document.getElementById("check_mac").style.display = "";
return false;
}else if(flag ==2){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<#325#>";
document.getElementById("check_mac").style.display = "";
return false;
}else{
document.getElementById("check_mac") ? document.getElementById("check_mac").style.display="none" : true;
return true;
}
}
function addRow_main(obj){
var category_array = $(obj.parentNode).siblings()[2].children;
var subCategory_array;
var category_checkbox;
var enable_checkbox = $(obj.parentNode).siblings()[0].children[0];
var first_catID = 0;
var invalid_char = "";
var blank_category = 0;
var apps_filter_row = apps_filter.split("<");
var apps_filter_col = "";
var upper = MaxRule_bwdpi_wrs>0?MaxRule_bwdpi_wrs:16;
if(apps_filter.split("<").length >= upper){
alert("<#2523#> " + upper + " <#2524#>");
document.form.PC_devicename.focus();
document.form.PC_devicename.select();
return false;
}
if(document.form.PC_devicename.value == ""){
alert("<#332#>");
document.form.PC_devicename.focus();
return false;
}
else if(!check_macaddr(document.form.PC_devicename, check_hwaddr_flag(document.form.PC_devicename, 'inner'))){
document.form.PC_devicename.focus();
document.form.PC_devicename.select();
return false;
}
for(var i=0; i < category_array.length;i++){
subCategory_array = category_array[i].children[2].children;
for(var j=0;j<subCategory_array.length;j++){
category_checkbox = category_array[i].children[2].children[j].children[1];
if(category_checkbox.checked)
blank_category = 1;
}
}
for(var i=0;i<apps_filter_row.length;i++){
if(apps_filter_row[i] != "") {
apps_filter_col = apps_filter_row[i].split(">");
if(apps_filter_col[1].toUpperCase() == document.form.PC_devicename.value.toUpperCase()){
alert("<#2516#>");
document.form.PC_devicename.value = "";
return false;
}
}
}
if(blank_category == 0){
alert("<#1325#>");
return false;
}
if(apps_filter == ""){
apps_filter += enable_checkbox.checked ? 1:0;
}
else{
apps_filter += "<";
apps_filter += enable_checkbox.checked ? 1:0;
}
apps_filter += ">" + document.form.PC_devicename.value.toUpperCase() + ">";
/* To check which checkbox is checked*/
for(var i=0; i < category_array.length;i++){
first_catID = 0;
subCategory_array = category_array[i].children[2].children;
for(var j=0;j<subCategory_array.length;j++){
category_checkbox = category_array[i].children[2].children[j].children[1];
if(first_catID == 0){
apps_filter += category_checkbox.checked ? 1:0;
first_catID = 1;
}
else{
apps_filter += ",";
apps_filter += category_checkbox.checked ? 1:0;
}
if(category_checkbox.checked)
blank_category = 1;
}
if(i != category_array.length -1)
apps_filter += ">";
}
document.form.PC_devicename.value = "";
genMain_table();
}
function genMain_table(){
var category_name = ["<#1228#>", "<#1243#>", "<#1246#>", "<#1250#>"];
var sub_category_name = [["<#1230#>", "<#1231#>", "<#1232#>"],
["<#1233#>", "<#1234#>", "<#1235#>", "<#1236#>", "<#1237#>"],
["<#1248#>", "<#1249#>"],
["<#1251#>", "<#1252#>", "<#1253#>"]];
var category_desc = ["<#1229#>",
"<#1244#>",
"<#1247#>",
"<#1254#>"];
var apps_filter_row = apps_filter.split("<");
var code = "";
var clientListEventData = [];
code += '<table width="100%" border="1" cellspacing="0" cellpadding="4" align="center" class="FormTable_table" id="mainTable_table">';
code += '<thead><tr>';
code += '<td colspan="5"><#1642#>&nbsp;(<#2655#>&nbsp;'+MaxRule_bwdpi_wrs+')</td>';
code += '</tr></thead>';
code += '<tbody>';
code += '<tr>';
code += '<th width="5%" height="30px" title="<#3155#>">';
code += '<input id="selAll" type="checkbox" onclick="selectAll(this, 0);" value="">';
code += '</th>';
code += '<th width="40%"><#1552#> (<#3004#>)</th>';
code += '<th width="40%"><#1238#></th>';
code += '<th width="10%"><#2654#></th>';
code += '</tr>';
code += '<tr id="main_element">';
code += '<td style="border-bottom:2px solid #000;" title="<#3944#>/<#1535#>">';
code += '<input type="checkbox" checked="">';
code += '</td>';
code += '<td style="border-bottom:2px solid #000;">';
code += '<input type="text" maxlength="17" style="margin-left:10px;float:left;width:255px;" class="input_20_table" name="PC_devicename" onkeypress="return validator.isHWAddr(this,event)" onclick="hideClients_Block();" placeholder="ex: <% nvram_get("lan_hwaddr"); %>" autocorrect="off" autocapitalize="off">';
code += '<img id="pull_arrow" height="14px;" src="/images/arrow-down.gif" onclick="pullLANIPList(this);" title="<#3158#>">';
code += '<div id="ClientList_Block_PC" class="clientlist_dropdown" style="margin-top:25px;margin-left:10px;"></div>';
code += '</td>';
code += '<td style="border-bottom:2px solid #000;text-align:left;">';
for(var i=0;i<category_name.length;i++){
code += '<div style="font-size:14px;font-weight:bold">';
code += '<img class="closed" src="/images/Tree/vert_line_s10.gif" onclick="show_subCategory(this);">';
code += '<input type="checkbox" onclick="set_category(this, 0);">'+category_name[i];
code += '<div style="display:none;font-size:12px;">';
for(var j=0;j<sub_category_name[i].length;j++){
code += '<div style="margin-left:20px;"><img src="/images/Tree/vert_line_s01.gif"><input type="checkbox" onclick="set_category(this, 1);">' + sub_category_name[i][j] + '</div>';
}
code += '</div>';
code += '<div class="hint-color" style="margin-left:25px;font-size:12px;font-weight:normal;">'+ category_desc[i] +'</div>';
code += '</div>';
}
code += '</td>';
code += '<td style="border-bottom:2px solid #000;"><input class="add_btn" type="button" onclick="addRow_main(this)" value=""></td>';
code += '</tr>';
if(apps_filter == ""){
code += '<tr><td style="color:#FFCC00;" colspan="10"><#2447#></td></tr>';
}
else{
for(var k=0;k< apps_filter_row.length;k++){
var apps_filter_col = apps_filter_row[k].split('>');
/* for exception */
if(apps_filter_col.length < 6){
if(apps_filter_col.length == 5){
apps_filter_col.push("0,0,0");
}
else if(apps_filter_col.length == 4){
apps_filter_col.push("0,0");
apps_filter_col.push("0,0,0");
}
else if(apps_filter_col.length == 3){
if(apps_filter_col[1].length != 17){ // check MAC address integrity
continue;
}
else{
apps_filter_col.push("0,0,0,0,0");
apps_filter_col.push("0,0");
apps_filter_col.push("0,0,0");
}
}
apps_filter_col[0] = "0";
}
/*End exception*/
var userIconBase64 = "NoIcon";
var clientName, clientMac, clientIP, deviceType, deviceVender;
var clientMac = apps_filter_col[1].toUpperCase();
var clientIconID = "clientIcon_" + clientMac.replace(/\:/g, "");
var clientObj = clientList[clientMac];
if(clientObj) {
clientName = (clientObj.nickName == "") ? clientObj.name : clientObj.nickName;
clientIP = clientObj.ip;
deviceType = clientObj.type;
deviceVender = clientObj.vendor;
}
else {
clientName = "New device";
clientIP = "offline";
deviceType = 0;
deviceVender = "";
}
code += '<tr>';
code += '<td title="<#3944#>/<#1535#>">';
if(apps_filter_col[0] == 1)
code += '<input type="checkbox" checked>';
else
code += '<input type="checkbox">';
code += '</td>';
code +='<td title="' + clientMac + '">';
code += '<table style="width:100%;"><tr><td style="width:40%;height:56px;border:0px;float:right;margin-right:20px;">';
if(clientObj == undefined) {
code += '<div id="' + clientIconID + '" class="clientIcon type0"></div>';
}
else {
if(usericon_support) {
userIconBase64 = getUploadIcon(clientMac.replace(/\:/g, ""));
}
if(userIconBase64 != "NoIcon") {
code += '<div id="' + clientIconID + '" style="text-align:center;"><img class="imgUserIcon_card" src="' + userIconBase64 + '"></div>';
}
else if(deviceType != "0" || deviceVender == "") {
code += '<div id="' + clientIconID + '" class="clientIcon type' + deviceType + '"></div>';
}
else if(deviceVender != "" ) {
var venderIconClassName = getVenderIconClassName(deviceVender.toLowerCase());
if(venderIconClassName != "" && !downsize_4m_support) {
code += '<div id="' + clientIconID + '" class="venderIcon ' + venderIconClassName + '"></div>';
}
else {
code += '<div id="' + clientIconID + '" class="clientIcon type' + deviceType + '"></div>';
}
}
}
code += '</td><td style="width:60%;border:0px;text-align:left;">';
code += '<div>' + clientName + '</div>';
code += '<div>' + clientMac + '</div>';
code += '</td></tr></table>';
code +='</td>';
code += '<td style="text-align:left;">';
for(var i=0;i<category_name.length;i++){
var cate_flag_array = new Array(apps_filter_col[i+2]);
var cate_flag_array_col = cate_flag_array[0].split(",");
var cate_flag = cate_flag_array[0].indexOf('1');
code += '<div>';
code += '<img class="closed" src="/images/Tree/vert_line_s10.gif" onclick="show_subCategory(this);">';
if(cate_flag != -1){
code += '<input type="checkbox" onclick="set_category(this, 0);" checked>'+category_name[i];
}
else{
code += '<input type="checkbox" onclick="set_category(this, 0);">'+category_name[i];
}
code += '<div style="display:none;">';
for(var j=0;j<sub_category_name[i].length;j++){
if(cate_flag_array_col[j] == 1){
code += '<div style="margin-left:20px;"><img src="/images/Tree/vert_line_s01.gif"><input type="checkbox" onclick="set_category(this, 1);" checked>' + sub_category_name[i][j] + '</div>';
}
else{
code += '<div style="margin-left:20px;"><img src="/images/Tree/vert_line_s01.gif"><input type="checkbox" onclick="set_category(this, 1);">' + sub_category_name[i][j] + '</div>';
}
}
code += '</div>';
code += '</div>';
}
code += '</td>';
code += '<td><input class="remove_btn" type="button" onclick="deleteRow_main(this);"></td>';
code += '</tr>';
if(validator.mac_addr(clientMac))
clientListEventData.push({"mac" : clientMac, "name" : clientName, "ip" : clientIP, "callBack" : "WebProtector"});
}
}
code += '</tbody>';
code += '</table>';
document.getElementById('mainTable').innerHTML = code;
for(var i = 0; i < clientListEventData.length; i += 1) {
var clientIconID = "clientIcon_" + clientListEventData[i].mac.replace(/\:/g, "");
var clientIconObj = $("#mainTable").children("#mainTable_table").find("#" + clientIconID + "")[0];
var paramData = JSON.parse(JSON.stringify(clientListEventData[i]));
paramData["obj"] = clientIconObj;
$("#mainTable").children("#mainTable_table").find("#" + clientIconID + "").click(paramData, popClientListEditTable);
}
showDropdownClientList('setClientIP', 'mac', 'all', 'ClientList_Block_PC', 'pull_arrow', 'all');
}
function edit_table(){
var apps_filter_temp = "";
var first_element = $('#main_element').siblings();
for(var k=1;k<first_element.length;k++){
var enable_checkbox = first_element[k].children[0].children[0].checked ? 1:0;
var target_mac = first_element[k].children[1].title;
var category_array = first_element[k].children[2].children;
var subCategory_array;
var category_checkbox;
var first_catID = 0;
var blank_category = 0;
if(k == 1)
apps_filter_temp += enable_checkbox;
else{
apps_filter_temp += "<" + enable_checkbox;;
}
apps_filter_temp += ">" + target_mac + ">";
for(var i=0; i < category_array.length;i++){
first_catID = 0;
subCategory_array = category_array[i].children[2].children;
for(var j=0;j<subCategory_array.length;j++){
category_checkbox = category_array[i].children[2].children[j].children[1];
if(category_checkbox.checked)
blank_category = 1;
if(first_catID == 0){
apps_filter_temp += category_checkbox.checked ? 1:0;
first_catID = 1;
}
else{
apps_filter_temp += ",";
apps_filter_temp += category_checkbox.checked ? 1:0;
}
}
if(i != category_array.length -1)
apps_filter_temp += ">";
}
if(blank_category == 0){
alert("<#1325#>");
return false;
}
}
apps_filter = apps_filter_temp;
return true;
}
var ctf_disable = '<% nvram_get("ctf_disable"); %>';
var ctf_fa_mode = '<% nvram_get("ctf_fa_mode"); %>';
var reboot_confirm=0;
function applyRule(){
document.form.action_script.value = "restart_wrs;restart_firewall";
if(amesh_support && isSwMode("rt") && ameshRouter_support)
document.form.action_script.value += ";apply_amaslib";
if(document.form.wrs_enable.value == "1") {
var apps_filter_row = "";
if(document.form.PC_devicename.value != ""){
alert("<#327#>");
return false;
}
if(apps_filter != ""){
if(edit_table())
apps_filter_row = apps_filter.split("<");
else
return false;
}
var wrs_rulelist = "";
var apps_rulelist = "";
for(var i=0;i<apps_filter_row.length;i++){
var apps_filter_col = apps_filter_row[i].split(">");
for(var j=0;j<apps_filter_col.length;j++){
if(j == 0){
if(wrs_rulelist == ""){
wrs_rulelist += apps_filter_col[j] + ">";
apps_rulelist += apps_filter_col[j] + ">";
}
else{
wrs_rulelist += "<" + apps_filter_col[j] + ">";
apps_rulelist += "<" + apps_filter_col[j] + ">";
}
}
else if(j == 1){
wrs_rulelist += apps_filter_col[j] + ">";
apps_rulelist += apps_filter_col[j] + ">";
}
else{
var cate_id_array = apps_filter_col[j].split(",");
var wrs_first_cate = 0;
var apps_first_cate = 0;
for(var k=0;k<cate_id_array.length;k++){
if(cate_id_array[k] == 1){
if(wrs_first_cate == 0){
if(wrs_id_array[j-2][k] != ""){
wrs_rulelist += wrs_id_array[j-2][k];
wrs_first_cate = 1;
}
}
else{
if(wrs_id_array[j-2][k] != ""){
wrs_rulelist += "," + wrs_id_array[j-2][k];
}
}
if(apps_first_cate == 0){
if(apps_id_array[j-2][k] != ""){
apps_rulelist += apps_id_array[j-2][k];
apps_first_cate = 1;
}
}
else{
if(apps_id_array[j-2][k] != ""){
apps_rulelist += "," + apps_id_array[j-2][k];
}
}
}
}
if(j != apps_filter_col.length-1){
wrs_rulelist += ">";
apps_rulelist += ">";
}
}
}
}
document.form.wrs_rulelist.value = wrs_rulelist;
document.form.wrs_app_rulelist.value = apps_rulelist;
if(ctf_disable == 0 && ctf_fa_mode == 2){
if(!confirm("<#1661#>")){
return false;
}
else{
reboot_confirm=1;
}
}
if(reset_wan_to_fo.change_status)
reset_wan_to_fo.change_wan_mode(document.form);
}
if(reboot_confirm==1){
if(confirm("<#65#>")){
FormActions("start_apply.htm", "apply", "reboot", "<% get_default_reboot_time(); %>");
showLoading();
document.form.submit();
}
}
else{
showLoading();
document.form.submit();
}
}
function translate_category_id(){
var mapping_array_init = [[0,0,0], [0,0,0,0,0], [0,0], [0,0,0]];
var apps_filter_row = "";
var wrs_filter_row = "";
var wrs_app_filter_row = "";
if(apps_filter != "")
apps_filter_row = apps_filter.split("<");
if(wrs_filter != "" || wrs_app_filter != ""){
wrs_filter_row = wrs_filter.split("<");
wrs_app_filter_row = wrs_app_filter.split("<");
}
var apps_filter_temp = "";
var wrs_filter_temp = "";
var wrs_app_filter_temp = "";
for(var i=0;i<wrs_filter_row.length;i++){
var apps_filter_col = apps_filter_row[i].split(">");
var wrs_filter_col = wrs_filter_row[i].split(">");
var wrs_app_filter_col = wrs_app_filter_row[i].split(">");
for(var j=0;j<wrs_filter_col.length;j++){
if(j == 0){
if(apps_filter_temp == "")
apps_filter_temp += wrs_filter_col[j] + ">";
else
apps_filter_temp += "<" + wrs_filter_col[j] + ">";
}
else if(j == 1){
apps_filter_temp += wrs_filter_col[j] + ">";
}
else{
for(var k=0;k<mapping_array_init[j-2].length;k++){
if(wrs_filter_col[j] != "" && wrs_app_filter_col[j] != ""){
if(wrs_id_array[j-2][k] != ""){
if(wrs_id_array[j-2][k] != "" && (wrs_filter_col[j].indexOf(wrs_id_array[j-2][k]) != -1)){
mapping_array_init[j-2][k] = 1;
}
}
if(apps_id_array[j-2][k] != ""){
if(apps_id_array[j-2][k] != "" && (wrs_app_filter_col[j].indexOf(apps_id_array[j-2][k]) != -1)){
mapping_array_init[j-2][k] = 1;
}
}
}
else if(wrs_filter_col[j] != ""){
if(wrs_id_array[j-2][k] != "" && (wrs_filter_col[j].indexOf(wrs_id_array[j-2][k]) != -1)){
mapping_array_init[j-2][k] = 1;
}
}
else if(wrs_app_filter_col[j] != ""){
if(apps_id_array[j-2][k]!= "" && (wrs_app_filter_col[j].indexOf(apps_id_array[j-2][k]) != -1)){
mapping_array_init[j-2][k] = 1;
}
}
else{
mapping_array_init[j-2][k] = 0;
}
if(k == 0)
apps_filter_temp += mapping_array_init[j-2][k];
else
apps_filter_temp += "," + mapping_array_init[j-2][k];
}
if(j != apps_filter_col.length-1 )
apps_filter_temp += ">";
}
}
mapping_array_init = [[0,0,0], [0,0,0,0,0], [0,0], [0,0,0]];
}
apps_filter = apps_filter_temp;
}
function show_inner_tab(){
var code = "";
if(document.form.current_page.value == "ParentalControl.asp"){
code += '<span class="clicked">Time Limits</span>';
code += '<a href="AiProtection_WebProtector.asp">';
code += "<span style=\"margin-left:10px\" class=\"click\"><#1227#></span>";
code += '</a>';
}
else{
code += '<a href="ParentalControl.asp">';
code += '<span class="click">Time Limits</span>';
code += '</a>';
code += "<span style=\"margin-left:10px\" class=\"clicked\"><#1227#></span>";
}
document.getElementById('switch_menu').innerHTML = code;
}
function cancel(){
$('#iphone_switch').animate({backgroundPosition: -37}, "slow", function() {});
curState = 0;
document.form.action_script.value = "";
document.form.action_wait.value = "5";
}
function eula_confirm(){
document.form.TM_EULA.value = 1;
document.form.wrs_enable.value = 1;
document.form.wrs_app_enable.value = 1;
document.form.action_wait.value = "15";
applyRule();
}
function switch_control(_status){
if(_status) {
if(reset_wan_to_fo.check_status()) {
if(ASUS_EULA.check("tm")){
document.form.wrs_enable.value = 1;
document.form.wrs_app_enable.value = 1;
applyRule();
}
}
else
cancel();
}
else {
document.form.wrs_enable.value = 0;
document.form.wrs_app_enable.value = 0;
showhide("list_table",0);
document.form.wrs_rulelist.disabled = true;
document.form.wrs_app_rulelist.disabled = true;
applyRule();
}
}
</script>
</head>
<body onload="initial();" onunload="unload_body();" class="bg">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<div id="hiddenMask" class="popup_bg" style="z-index:999;">
<table cellpadding="5" cellspacing="0" id="dr_sweet_advise" class="dr_sweet_advise" align="center"></table>
<!--[if lte IE 6.5]><script>alert("<#1376#>");</script><![endif]-->
</div>
<iframe name="hidden_frame" id="hidden_frame" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" name="productid" value="<% nvram_get("productid"); %>">
<input type="hidden" name="current_page" value="AiProtection_WebProtector.asp">
<input type="hidden" name="next_page" value="">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="action_wait" value="5">
<input type="hidden" name="action_mode" value="apply">
<input type="hidden" name="action_script" value="">
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>" disabled>
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>">
<input type="hidden" name="wrs_enable" value="<% nvram_get("wrs_enable"); %>">
<input type="hidden" name="wrs_enable_ori" value="<% nvram_get("wrs_enable"); %>">
<input type="hidden" name="wrs_app_enable" value="<% nvram_get("wrs_app_enable"); %>">
<input type="hidden" name="wrs_rulelist" value="">
<input type="hidden" name="wrs_app_rulelist" value="">
<input type="hidden" name="TM_EULA" value="<% nvram_get("TM_EULA"); %>">
<table class="content" align="center" cellpadding="0" cellspacing="0" >
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
<div id="mainMenu"></div>
<div id="subMenu"></div>
</td>
<td valign="top">
<div id="tabMenu" class="submenuBlock"></div>
<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0" >
<tr>
<td valign="top" >
<table width="730px" border="0" cellpadding="4" cellspacing="0" class="FormTitle" id="FormTitle">
<tr>
<td bgcolor="#4D595D" valign="top">
<div>&nbsp;</div>
<div style="margin-top:-5px;">
<table width="730px">
<tr>
<td align="left">
<div class="formfonttitle" style="width:400px"><#482#> - <#1227#></div>
</td>
<td style="display:none;">
<div id="switch_menu" style="margin:-20px 0px 0px 0px;">
<div style="width:168px;height:30px;border-top-left-radius:8px;border-bottom-left-radius:8px;" class="block_filter_pressed">
<table class="block_filter_name_table_pressed"><tr><td style="line-height:13px;"><#1227#></td></tr></table>
</div>
<a href="ParentalControl.asp">
<div style="width:160px;height:30px;margin:-32px 0px 0px 168px;border-top-right-radius:8px;border-bottom-right-radius:8px;" class="block_filter">
<table class="block_filter_name_table"><tr><td style="line-height:13px;"><#3357#></td></tr></table>
</div>
</a>
</div>
</td>
</tr>
</table>
</div>
<div style="margin:0px 0px 10px 5px;" class="splitLine"></div>
<div id="PC_desc">
<table width="700px" style="margin-left:25px;">
<tr>
<td>
<img id="guest_image" src="/images/New_ui/Web_Apps_Restriction.png">
</td>
<td>&nbsp;&nbsp;</td>
<td style="font-size: 14px;">
<span><#1239#></span>
<ol>
<li><#1240#></li>
<li><#1241#></li>
<li><#1242#></li>
</ol>
<span><#1245#></span>
<div>
<a id="faq" href="" style="text-decoration:underline;" target="_blank"><#482#> FAQ</a>
</div>
</td>
</tr>
</table>
</div>
<br>
<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
<tr>
<th><#1227#></th>
<td>
<div align="center" class="left" style="width:94px; float:left; cursor:pointer;" id="radio_web_restrict_enable"></div>
<div class="iphone_switch_container" style="height:32px; width:74px; position: relative; overflow: hidden">
<script type="text/javascript">
$('#radio_web_restrict_enable').iphoneSwitch('<% nvram_get("wrs_enable"); %>',
function(){
switch_control(1);
},
function(){
switch_control(0);
}
);
</script>
</div>
</td>
</tr>
<tr style="display:none;">
<th>Enable Block Notification page</th>
<td>
<div align="center" class="left" style="width:94px; float:left; cursor:pointer;" id="block_notification_enable"></div>
<div class="iphone_switch_container" style="height:32px; width:74px; position: relative; overflow: hidden">
<script type="text/javascript">
$('#block_notification_enable').iphoneSwitch('<% nvram_get(""); %>',
function(){
},
function(){
}
);
</script>
</div>
</td>
</tr>
</table>
<table id="list_table" width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="display:none">
<tr>
<td valign="top" align="center">
<div id="mainTable" style="margin-top:10px;"></div>
<div id="ctrlBtn" style="text-align:center;margin-top:20px;">
<input class="button_gen" type="button" onclick="applyRule();" value="<#203#>">
<div style="width:96px;height:44px;position:absolute;bottom:5px;right:5px;background-image:url('images/New_ui/TrendMirco_logo.svg');background-size: 100%;"></div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="10" align="center" valign="top">&nbsp;</td>
</tr>
</table>
<div id="footer"></div>
</form>
</body>
</html>

