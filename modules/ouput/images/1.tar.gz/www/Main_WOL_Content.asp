﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<title><#2848#> - <#2865#></title>
<link rel="stylesheet" type="text/css" href="index_style.css">
<link rel="stylesheet" type="text/css" href="form_style.css">
<link rel="stylesheet" type="text/css" href="/device-map/device-map.css">
<style>
</style>
<script language="JavaScript" type="text/javascript" src="/state.js"></script>
<script language="JavaScript" type="text/javascript" src="/general.js"></script>
<script language="JavaScript" type="text/javascript" src="/popup.js"></script>
<script language="JavaScript" type="text/javascript" src="/help.js"></script>
<script language="JavaScript" type="text/javascript" src="/validator.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/jquery.js"></script>
<script language="JavaScript" type="text/javascript" src="/client_function.js"></script>
<script type="text/javascript" src="/js/httpApi.js"></script>
<script>
var wollist_array = decodeURIComponent('<% nvram_char_to_ascii("", "wollist"); %>').replace(/>/g, "&#62").replace(/</g, "&#60");
var manually_wol_list_array = new Array();
var faq_href = "https://nw-dlcdnet.asus.com/support/forward.html?model=&type=Faq&lang="+ui_lang+"&kw=&num=145";
function initial(){
show_menu();
document.getElementById("faq3").href=faq_href; // id in #smart_access3#
var wollist_row = wollist_array.split('&#60');
for(var i = 1; i < wollist_row.length; i += 1) {
var wollist_col = wollist_row[i].split('&#62');
manually_wol_list_array[wollist_col[1]] = wollist_col[0];
}
showwollist();
setTimeout("showDropdownClientList('setClientIP', 'mac', 'all', 'ClientList_Block_PC', 'pull_arrow', 'all');", 1000);
}
function onSubmitCtrl(o, s) {
if(document.form.destIP.value == ""){
alert("<#332#>");
document.form.destIP.focus();
return false;
}
if(check_hwaddr_flag(document.form.destIP, 'inner') != 0){
alert("<#325#>");
document.form.destIP.focus();
return false;
}
document.form.action_mode.value = s;
updateOptions();
}
function updateOptions(){
document.form.SystemCmd.value = "ether-wake -i br0 " + document.form.destIP.value;
document.form.submit();
document.getElementById("cmdBtn").disabled = true;
document.getElementById("cmdBtn").style.color = "#666";
document.getElementById("loadingIcon").style.display = "";
setTimeout("checkCmdRet();", 500);
}
var _responseLen;
var noChange = 0;
function checkCmdRet(){
$.ajax({
url: '/cmdRet_check.htm',
dataType: 'html',
error: function(xhr){
setTimeout("checkCmdRet();", 1000);
},
success: function(response){
if(response.search("XU6J03M6") != -1){
document.getElementById("loadingIcon").style.display = "none";
document.getElementById("cmdBtn").disabled = false;
document.getElementById("cmdBtn").style.color = "#FFF";
return false;
}
if(_responseLen == response.length)
noChange++;
else
noChange = 0;
if(noChange > 5){
document.getElementById("loadingIcon").style.display = "none";
document.getElementById("cmdBtn").disabled = false;
document.getElementById("cmdBtn").style.color = "#FFF";
setTimeout("checkCmdRet();", 1000);
}
else{
document.getElementById("cmdBtn").disabled = true;
document.getElementById("cmdBtn").style.color = "#666";
document.getElementById("loadingIcon").style.display = "";
setTimeout("checkCmdRet();", 1000);
}
_responseLen = response.length;
}
});
}
function showwollist(){
var code = "";
var clientListEventData = [];
code += '<table width="100%" cellspacing="0" cellpadding="4" align="center" class="list_table" id="wollist_table">';
if(Object.keys(manually_wol_list_array).length == 0)
code += '<tr><td style="color:#FFCC00;"><#2447#></td></tr>';
else{
var userIconBase64 = "NoIcon";
var clientName, deviceType, deviceVender;
Object.keys(manually_wol_list_array).forEach(function(key) {
clientName = manually_wol_list_array[key];
if(clientList[key]) {
clientName = (clientList[key].nickName == "") ? clientList[key].name : clientList[key].nickName;
manually_wol_list_array[key] = clientName;
}
var clientMac = key.toUpperCase();
var clientIconID = "clientIcon_" + clientMac.replace(/\:/g, "");
code += '<tr>';
code += '<td width="80%" align="center">';
if(clientList[clientMac]) {
deviceType = clientList[clientMac].type;
deviceVender = clientList[clientMac].vendor;
}
else {
deviceType = 0;
deviceVender = "";
}
code += '<table style="width:100%;"><tr><td style="width:40%;height:56px;border:0px;float:right;">';
if(clientList[clientMac] == undefined) {
code += '<div id="' + clientIconID + '" class="clientIcon type0"></div>';
}
else {
if(usericon_support) {
userIconBase64 = getUploadIcon(clientMac.replace(/\:/g, ""));
}
if(userIconBase64 != "NoIcon") {
code += '<div id="' + clientIconID + '" style="text-align:center;"><img class="imgUserIcon_card" src="' + userIconBase64 + '"></div>';
}
else if(deviceType != "0" || deviceVender == "") {
code += '<div id="' + clientIconID + '" class="clientIcon type' + deviceType + '"></div>';
}
else if(deviceVender != "" ) {
var venderIconClassName = getVenderIconClassName(deviceVender.toLowerCase());
if(venderIconClassName != "" && !downsize_4m_support) {
code += '<div id="' + clientIconID + '" class="venderIcon ' + venderIconClassName + '"></div>';
}
else {
code += '<div id="' + clientIconID + '" class="clientIcon type' + deviceType + '"></div>';
}
}
}
code += '</td><td style="width:60%;border:0px;">';
code += '<div>' + clientName + '</div>';
code += '<div style="font-weight:bold;cursor:pointer;text-decoration:underline;font-family:Lucida Console;" onclick="document.form.destIP.value=this.innerHTML;">' + clientMac + '</div>';
code += '</td></tr></table>';
code += '</td>';
code += '<td width="20%">';
code += '<input class="remove_btn" onclick="del_Row(this, \'' + clientMac + '\');" value=""/></td></tr>';
if(validator.mac_addr(clientMac))
clientListEventData.push({"mac" : clientMac, "name" : "", "ip" : "", "callBack" : "WOL"});
});
}
code += '</table>';
document.getElementById("wollist_Block").innerHTML = code;
for(var i = 0; i < clientListEventData.length; i += 1) {
var clientIconID = "clientIcon_" + clientListEventData[i].mac.replace(/\:/g, "");
var clientIconObj = $("#wollist_Block").children("#wollist_table").find("#" + clientIconID + "")[0];
var paramData = JSON.parse(JSON.stringify(clientListEventData[i]));
paramData["obj"] = clientIconObj;
$("#wollist_Block").children("#wollist_table").find("#" + clientIconID + "").click(paramData, popClientListEditTable);
}
}
function addRow_Group(upper){
var rule_num = document.getElementById('wollist_table').rows.length;
var item_num = document.getElementById('wollist_table').rows[0].cells.length;
if(rule_num >= upper){
alert("<#2523#> " + upper + " <#2524#>");
return false;
}
if(document.form.wollist_macAddr.value==""){
alert("<#332#>");
document.form.wollist_macAddr.focus();
document.form.wollist_macAddr.select();
return false;
}else if(!check_macaddr(document.form.wollist_macAddr, check_hwaddr_flag(document.form.wollist_macAddr, 'inner'))){
document.form.wollist_macAddr.focus();
document.form.wollist_macAddr.select();
return false;
}
if(item_num >=2){
for(i=0; i<rule_num; i++){
if(manually_wol_list_array[document.form.wollist_macAddr.value.toUpperCase()] != null){
alert("<#2516#>");
document.form.wollist_macAddr.focus();
document.form.wollist_macAddr.select();
return false;
}
}
}
var clientObj = clientList[document.form.wollist_macAddr.value.toUpperCase()];
var clientName = "New device";
if(clientObj) {
clientName = (clientObj.nickName == "") ? clientObj.name : clientObj.nickName;
}
manually_wol_list_array[document.form.wollist_macAddr.value.toUpperCase()] = clientName;
document.form.wollist_macAddr.value = "";
showwollist();
}
function check_macaddr(obj,flag){ //control hint of input mac address
if(flag == 1){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<#364#>";
document.getElementById("check_mac").style.display = "";
return false;
}else if(flag ==2){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<#325#>";
document.getElementById("check_mac").style.display = "";
return false;
}else{
document.getElementById("check_mac") ? document.getElementById("check_mac").style.display="none" : true;
return true;
}
}
function del_Row(r, delMac){
var i = r.parentNode.parentNode.rowIndex;
delete manually_wol_list_array[delMac];
document.getElementById('wollist_table').deleteRow(i);
if(Object.keys(manually_wol_list_array).length == 0)
showwollist();
}
function setClientIP(_macaddr){
document.form.wollist_macAddr.value = _macaddr;
hideClients_Block();
}
function hideClients_Block(){
document.getElementById("pull_arrow").src = "/images/arrow-down.gif";
document.getElementById('ClientList_Block_PC').style.display='none';
}
function pullLANIPList(obj){
var element = document.getElementById('ClientList_Block_PC');
var isMenuopen = element.offsetWidth > 0 || element.offsetHeight > 0;
if(isMenuopen == 0){
obj.src = "/images/arrow-top.gif"
element.style.display = 'block';
document.form.wollist_macAddr.focus();
}
else
hideClients_Block();
}
function applyRule(){
var rule_num = document.getElementById('wollist_table').rows.length;
var item_num = document.getElementById('wollist_table').rows[0].cells.length;
var tmp_value = "";
Object.keys(manually_wol_list_array).forEach(function(key) {
tmp_value += "<" + manually_wol_list_array[key] + ">" + key;
});
if(tmp_value == "<"+"<#2447#>" || tmp_value == "<")
tmp_value = "";
document.wolform.wollist.value = tmp_value;
showLoading();
document.wolform.submit();
}
</script>
</head>
<body onload="initial();" class="bg">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="POST" name="form" action="/apply.cgi" target="hidden_frame">
<input type="hidden" name="current_page" value="Main_WOL_Content.asp">
<input type="hidden" name="next_page" value="Main_WOL_Content.asp">
<input type="hidden" name="group_id" value="">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="action_mode" value="">
<input type="hidden" name="action_script" value="">
<input type="hidden" name="action_wait" value="">
<input type="hidden" name="first_time" value="">
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>">
<input type="hidden" name="SystemCmd" onkeydown="onSubmitCtrl(this, ' Refresh ')" value="">
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>">
<table class="content" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
<div id="mainMenu"></div>
<div id="subMenu"></div>
</td>
<td valign="top">
<div id="tabMenu" class="submenuBlock"></div>
<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
<tr>
<td align="left" valign="top">
<table width="760px" border="0" cellpadding="5" cellspacing="0" bordercolor="#6b8fa3" class="FormTitle" id="FormTitle">
<tr>
<td bgcolor="#4D595D" colspan="3" valign="top">
<div>&nbsp;</div>
<div class="formfonttitle"><#2848#> - <#2865#></div>
<div style="margin:10px 0 10px 5px;" class="splitLine"></div>
<div class="formfontdesc"><#3230#></div>
<div class="formfontdesc"><#3231#></div>
<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
<tr>
<th width="20%"><#2863#></th>
<td>
<input type="text" class="input_20_table" maxlength="17" name="destIP" value="" placeholder="ex: <% nvram_get("lan_hwaddr"); %>" onKeyPress="return validator.isHWAddr(this,event);" autocorrect="off" autocapitalize="off">
<input class="button_gen" id="cmdBtn" onClick="onSubmitCtrl(this, ' Refresh ')" type="button" value="<#2866#>">
<img id="loadingIcon" style="display:none;" src="/images/InternetScan.gif"></span>
</td>
</tr>
</table>
<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" class="FormTable_table" style="margin-top:8px;">
<thead>
<tr>
<td colspan="2" id="GWStatic"><#2859#>&nbsp;(<#2655#>&nbsp;32)</td>
</tr>
</thead>
<tr>
<th><a class="hintstyle" href="javascript:void(0);" onClick="openHint(5,10);"><#1552#> (<#3004#>)</a></th>
<th><#2654#></th>
</tr>
<tr>
<td width="80%">
<input type="text" class="input_20_table" maxlength="17" name="wollist_macAddr" onClick="hideClients_Block();" autocorrect="off" autocapitalize="off" style="margin-left:-12px;width:255px;" onKeyPress="return validator.isHWAddr(this,event)" placeholder="ex: <% nvram_get("lan_hwaddr"); %>">
<img id="pull_arrow" height="14px;" src="/images/arrow-down.gif" style="position:absolute;*margin-left:-3px;*margin-top:1px;" onclick="pullLANIPList(this);" title="<#3159#>">
<div id="ClientList_Block_PC" class="clientlist_dropdown"></div>
</td>
<td width="20%">
<div>
<input type="button" class="add_btn" onClick="addRow_Group(32);" value="">
</div>
</td>
</tr>
</table>
<div id="wollist_Block"></div>
<div class="apply_gen">
<input type="button" name="button" class="button_gen" onclick="applyRule();" value="<#203#>"/>
</div>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="10" align="center" valign="top"></td>
</tr>
</table>
</form>
<form method="post" name="wolform" id="ruleForm" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" name="productid" value="<% nvram_get("productid"); %>">
<input type="hidden" name="current_page" value="Main_WOL_Content.asp">
<input type="hidden" name="next_page" value="Main_WOL_Content.asp">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="action_mode" value="apply">
<input type="hidden" name="action_wait" value="3">
<input type="hidden" name="action_script" value="restart_time">
<input type="hidden" name="wollist" value="<% nvram_get("wollist"); %>">
</form>
<div id="footer"></div>
</body>
</html>

