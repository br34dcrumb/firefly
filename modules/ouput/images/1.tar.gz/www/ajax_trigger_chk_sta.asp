﻿<% act_chksta(); %>

