﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html xmlns:v>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<title><#860#> - <#2697#></title>
<link rel="stylesheet" type="text/css" href="/index_style.css">
<link rel="stylesheet" type="text/css" href="/form_style.css">
<link rel="stylesheet" type="text/css" href="device-map/device-map.css">
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/help.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script type="text/javascript" src="/validator.js"></script>
<script language="JavaScript" type="text/javascript" src="/client_function.js"></script>
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/httpApi.js"></script>
<style>
.Portrange{
font-size: 12px;
font-family: Lucida Console;
}
</style>
<script>
var qos_rulelist_array = "<% nvram_char_to_ascii("","qos_rulelist"); %>";
var overlib_str0 = new Array(); //Viz add 2011.06 for record longer qos rule desc
var overlib_str = new Array(); //Viz add 2011.06 for record longer portrange value
var faq_href = "https://nw-dlcdnet.asus.com/support/forward.html?model=&type=Faq&lang="+ui_lang+"&kw=&num=110";
function key_event(evt){
if(evt.keyCode != 27 || isMenuopen == 0)
return false;
pullQoSList(document.getElementById("pull_arrow"));
}
function initial(){
show_menu();
document.getElementById("faq").href=faq_href;
if(bwdpi_support){
document.getElementById('content_title').innerHTML = "<#2697#> - <#1932#>";
}
else{
document.getElementById('content_title').innerHTML = "<#392#> - QoS";
}
showqos_rulelist();
load_QoS_rule();
if('<% nvram_get("qos_enable"); %>' == "1")
document.getElementById('is_qos_enable_desc').style.display = "none";
setTimeout("showDropdownClientList('setClientIP_mac', 'name>mac', 'all', 'ClientList_Block_PC', 'pull_arrow_mac', 'all');", 1000);
}
function applyRule(){
save_table();
showLoading();
document.form.submit();
}
function save_table(){
var rule_num = document.getElementById('qos_rulelist_table').rows.length;
var item_num = document.getElementById('qos_rulelist_table').rows[0].cells.length;
var tmp_value = "";
var comp_tmp = "";
for(i=0; i<rule_num; i++){
tmp_value += "<"
for(j=0; j<item_num-1; j++){
if(j==5){
tmp_value += document.getElementById('qos_rulelist_table').rows[i].cells[j].firstChild.value;
}else{
if(document.getElementById('qos_rulelist_table').rows[i].cells[j].innerHTML.lastIndexOf("...")<0){
tmp_value += document.getElementById('qos_rulelist_table').rows[i].cells[j].innerHTML;
}else{
tmp_value += document.getElementById('qos_rulelist_table').rows[i].cells[j].title;
}
}
if(j != item_num-2)
tmp_value += ">";
}
}
if(tmp_value == "<"+"<#2447#>" || tmp_value == "<")
tmp_value = "";
document.form.qos_rulelist.value = tmp_value;
}
function done_validating(action){
refreshpage();
}
function addRow(obj, head){
if(head == 1)
qos_rulelist_array += "<"
else
qos_rulelist_array += ">"
qos_rulelist_array += obj.value;
obj.value= "";
document.form.qos_min_transferred_x_0.value= "";
document.form.qos_max_transferred_x_0.value= "";
}
function validForm(){
if(document.form.qos_service_name_x_0.value == '<#742#>'){ // when service name is default "Please select", change it to null value. Jieming added at 2012/12/21
document.form.qos_service_name_x_0.value = "";
}
if(!Block_chars(document.form.qos_service_name_x_0, ["<" ,">" ,"'" ,"%"])){
return false;
}
if(document.form.qos_ip_x_0.value != "") {
if(document.form.qos_ip_x_0.value.split(":").length == 6) { //mac
if(!validator.mac_addr(document.form.qos_ip_x_0.value)) {
document.form.qos_ip_x_0.focus();
alert("<#364#>");
return false;
}
}
else if(document.form.qos_ip_x_0.value.split(".").length == 4) { //ip
if(!validator.ipv4_addr(document.form.qos_ip_x_0.value)) { //single ip
if(!validator.ipv4_addr_range(document.form.qos_ip_x_0.value)) { //ip range
document.form.qos_ip_x_0.focus();
alert(document.form.qos_ip_x_0.value + " <#346#>");
return false;
}
}
}
else {
document.form.qos_ip_x_0.focus();
alert(document.form.qos_ip_x_0.value + " <#2677#>");
return false;
}
}
replace_symbol();
if(document.form.qos_port_x_0.value != "" && !Check_multi_range(document.form.qos_port_x_0, 1, 65535)){
parse_port="";
return false;
}
if((document.form.qos_max_transferred_x_0.value.length > 0)
&& (parseInt(document.form.qos_max_transferred_x_0.value) < parseInt(document.form.qos_min_transferred_x_0.value))){
document.form.qos_max_transferred_x_0.focus();
alert("<#3591#> "+document.form.qos_min_transferred_x_0.value);
return false;
}
return true;
}
function addRow_Group(upper){
if(validForm()){
var rule_num = document.getElementById('qos_rulelist_table').rows.length;
var item_num = document.getElementById('qos_rulelist_table').rows[0].cells.length;
if(rule_num >= upper){
alert("<#2523#> " + upper + " <#2524#>");
return;
}
conv_to_transf();
if(item_num >=2){ //duplicate check: {IP/MAC, port, proto, transferred}
for(i=0; i<rule_num; i++){
if(overlib_str[i]){
if(document.form.qos_ip_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[1].innerHTML
&& document.form.qos_port_x_0.value == overlib_str[i]
&& document.form.qos_transferred_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[4].innerHTML){
if(document.form.qos_proto_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML
|| document.form.qos_proto_x_0.value == 'any'
|| document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'any'){
alert("<#2516#>");
parse_port="";
document.form.qos_port_x_0.value =="";
document.form.qos_ip_x_0.focus();
document.form.qos_ip_x_0.select();
return;
}else if(document.form.qos_proto_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML
|| (document.form.qos_proto_x_0.value == 'tcp/udp' && (document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'tcp' || document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'udp'))
|| (document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'tcp/udp' && (document.form.qos_proto_x_0.value == 'tcp' || document.form.qos_proto_x_0.value == 'udp'))){
alert("<#2516#>");
parse_port="";
document.form.qos_port_x_0.value =="";
document.form.qos_ip_x_0.focus();
document.form.qos_ip_x_0.select();
return;
}
}
}else{
if(document.form.qos_ip_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[1].innerHTML
&& document.form.qos_port_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[2].innerHTML
&& document.form.qos_transferred_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[4].innerHTML){
if(document.form.qos_proto_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML
|| document.form.qos_proto_x_0.value == 'any'
|| document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'any'){
alert("<#2516#>");
parse_port="";
document.form.qos_port_x_0.value =="";
document.form.qos_ip_x_0.focus();
document.form.qos_ip_x_0.select();
return;
}else if(document.form.qos_proto_x_0.value == document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML
|| (document.form.qos_proto_x_0.value == 'tcp/udp' && (document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'tcp' || document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'udp'))
|| (document.getElementById('qos_rulelist_table').rows[i].cells[3].innerHTML == 'tcp/udp' && (document.form.qos_proto_x_0.value == 'tcp' || document.form.qos_proto_x_0.value == 'udp'))){
alert("<#2516#>");
parse_port="";
document.form.qos_port_x_0.value =="";
document.form.qos_ip_x_0.focus();
document.form.qos_ip_x_0.select();
return;
}
}
}
}
}
addRow(document.form.qos_service_name_x_0 ,1);
addRow(document.form.qos_ip_x_0, 0);
addRow(document.form.qos_port_x_0, 0);
addRow(document.form.qos_proto_x_0, 0);
document.form.qos_proto_x_0.value="tcp/udp";
if(document.form.qos_transferred_x_0.value == "~")
document.form.qos_transferred_x_0.value = "";
addRow(document.form.qos_transferred_x_0, 0);
addRow(document.form.qos_prio_x_0, 0);
document.form.qos_prio_x_0.value="1";
showqos_rulelist();
}
}
function del_Row(r){
var i=r.parentNode.parentNode.rowIndex;
document.getElementById('qos_rulelist_table').deleteRow(i);
var qos_rulelist_value = "";
for(k=0; k<document.getElementById('qos_rulelist_table').rows.length; k++){
for(j=0; j<document.getElementById('qos_rulelist_table').rows[k].cells.length-1; j++){
if(j == 0)
qos_rulelist_value += "<";
else
qos_rulelist_value += ">";
if(j == 5){
qos_rulelist_value += document.getElementById('qos_rulelist_table').rows[k].cells[j].firstChild.value;
}else if(document.getElementById('qos_rulelist_table').rows[k].cells[j].innerHTML.lastIndexOf("...")<0){
qos_rulelist_value += document.getElementById('qos_rulelist_table').rows[k].cells[j].innerHTML;
}else{
qos_rulelist_value += document.getElementById('qos_rulelist_table').rows[k].cells[j].title;
}
}
}
qos_rulelist_array = qos_rulelist_value;
if(qos_rulelist_array == "")
showqos_rulelist();
}
function showqos_rulelist(){
var qos_rulelist_row = "";
qos_rulelist_row = decodeURIComponent(qos_rulelist_array).split('<');
var code = "";
code +='<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" class="list_table" id="qos_rulelist_table">';
if(qos_rulelist_row.length == 1) // no exist "<"
code +='<tr><td style="color:#FFCC00;" colspan="10"><#2447#></td></tr>';
else{
for(var i = 1; i < qos_rulelist_row.length; i++){
overlib_str0[i] ="";
overlib_str[i] ="";
code +='<tr id="row'+i+'">';
var qos_rulelist_col = qos_rulelist_row[i].split('>');
var wid=[20, 20, 10, 14, 15, 15];
for(var j = 0; j < qos_rulelist_col.length; j++){
if(j != 0 && j !=2 && j!=5){
code +='<td width="'+wid[j]+'%">'+ qos_rulelist_col[j] +'</td>';
}else if(j==0){
if(qos_rulelist_col[0].length >15){
overlib_str0[i] += qos_rulelist_col[0];
qos_rulelist_col[0]=qos_rulelist_col[0].substring(0, 13)+"...";
code +='<td width="'+wid[j]+'%" title="'+overlib_str0[i]+'">'+ qos_rulelist_col[0] +'</td>';
}else
code +='<td width="'+wid[j]+'%">'+ qos_rulelist_col[j] +'</td>';
}else if(j==2){
if(qos_rulelist_col[2].length >13){
overlib_str[i] += qos_rulelist_col[2];
qos_rulelist_col[2]=qos_rulelist_col[2].substring(0, 11)+"...";
code +='<td width="'+wid[j]+'%" title="'+overlib_str[i]+'">'+ qos_rulelist_col[2] +'</td>';
}else
code +='<td width="'+wid[j]+'%">'+ qos_rulelist_col[j] +'</td>';
}else if(j==5){
code += '<td width="'+wid[j]+'%"><select class="input_option" style="width:85px;">';
if(qos_rulelist_col[5] =="0")
code += '<option value="0" selected><#2317#></option>';
else
code += '<option value="0"><#2317#></option>';
if(qos_rulelist_col[5] =="1")
code += '<option value="1" selected><#2316#></option>';
else
code += '<option value="1"><#2316#></option>';
if(qos_rulelist_col[5] =="2")
code += '<option value="2" selected><#2690#></option>';
else
code += '<option value="2"><#2690#></option>';
if(qos_rulelist_col[5] =="3")
code += '<option value="3" selected><#2666#></option>';
else
code += '<option value="3"><#2666#></option>';
if(qos_rulelist_col[5] =="4")
code += '<option value="4" selected><#2667#></option>';
else
code += '<option value="4"><#2667#></option>';
code += '</select></td>';
}
}
code +='<td width="6%">';
code +='<input class="remove_btn" type="button" onclick="del_Row(this);" style="width:36px;"/></td></tr>';
}
}
code +='</table>';
document.getElementById("qos_rulelist_Block").innerHTML = code;
parse_port="";
}
function conv_to_transf(){
if(document.form.qos_min_transferred_x_0.value =="" &&document.form.qos_max_transferred_x_0.value =="")
document.form.qos_transferred_x_0.value = "";
else
document.form.qos_transferred_x_0.value = document.form.qos_min_transferred_x_0.value + "~" + document.form.qos_max_transferred_x_0.value;
}
function switchPage(page){
if(page == "1")
location.href = "/QoS_EZQoS.asp";
else if(page == "3")
location.href = "/Advanced_QOSUserPrio_Content.asp";
else
return false;
}
function validate_multi_port(val, min, max){
for(i=0; i<val.length; i++)
{
if (val.charAt(i)<'0' || val.charAt(i)>'9')
{
alert('<#350#> ' + min + ' <#351#> ' + max);
return false;
}
if(val<min || val>max) {
alert('<#350#> ' + min + ' <#351#> ' + max);
return false;
}else{
val = str2val(val);
if(val=="")
val="0";
return true;
}
}
}
function validate_multi_range(val, mini, maxi){
var rangere=new RegExp("^([0-9]{1,5})\:([0-9]{1,5})$", "gi");
if(rangere.test(val)){
if(!validator.eachPort(document.form.qos_port_x_0, RegExp.$1, mini, maxi) || !validator.eachPort(document.form.qos_port_x_0, RegExp.$2, mini, maxi)){
return false;
}else if(parseInt(RegExp.$1) >= parseInt(RegExp.$2)){
alert("<#347#>");
return false;
}else
return true;
}else{
if(!validate_single_range(val, mini, maxi)){
return false;
}
return true;
}
}
function validate_single_range(val, min, max) {
for(j=0; j<val.length; j++){ //is_number
if (val.charAt(j)<'0' || val.charAt(j)>'9'){
alert('<#350#> ' + min + ' <#351#> ' + max);
return false;
}
}
if(val < min || val > max) { //is_in_range
alert('<#350#> ' + min + ' <#351#> ' + max);
return false;
}else
return true;
}
var parse_port="";
function Check_multi_range(obj, mini, maxi){
obj.value = document.form.qos_port_x_0.value.replace(/[-~]/gi,":"); // "~-" to ":"
var PortSplit = obj.value.split(",");
for(i=0;i<PortSplit.length;i++){
PortSplit[i] = PortSplit[i].replace(/(^\s*)|(\s*$)/g, ""); // "\space" to ""
PortSplit[i] = PortSplit[i].replace(/(^0*)/g, ""); // "^0" to ""
if(!validate_multi_range(PortSplit[i], mini, maxi)){
obj.focus();
obj.select();
return false;
}
if(i ==PortSplit.length -1)
parse_port = parse_port + PortSplit[i];
else
parse_port = parse_port + PortSplit[i] + ",";
}
document.form.qos_port_x_0.value = parse_port;
return true;
}
var url_link = "/ajax_qos_default.xml";
function load_QoS_rule(){
free_options(document.form.qos_default_sel);
loadXMLDoc(url_link);
}
function loadXMLDoc(){
$.ajax({
url: '/ajax_qos_default.xml',
dataType: 'xml',
error: function(xhr){
setTimeout("loadXMLDoc();", 1000);
},
success: function(response){
Load_XML2form(response);
}
});
}
var QoS_rules;
var Sel_desc, Sel_port, Sel_proto, Sel_rate, Sel_prio;
var rule_desc = new Array();
var rule_port = new Array();
var rule_proto = new Array();
var rule_rate = new Array();
var rule_prio = new Array();
function Load_XML2form(obj){
QoS_rules = obj.getElementsByTagName("qos_rule");
for(i=0;i<QoS_rules.length;i++){
Sel_desc=QoS_rules[i].getElementsByTagName("desc");
Sel_port=QoS_rules[i].getElementsByTagName("port");
Sel_proto=QoS_rules[i].getElementsByTagName("proto");
Sel_rate=QoS_rules[i].getElementsByTagName("rate");
Sel_prio=QoS_rules[i].getElementsByTagName("prio");
add_option(document.form.qos_default_sel, Sel_desc[0].firstChild.nodeValue, i, 0);
if(Sel_desc[0].firstChild != null)
rule_desc[i] = Sel_desc[0].firstChild.nodeValue;
else
rule_desc[i] ="";
if(Sel_port[0].firstChild != null)
rule_port[i] = Sel_port[0].firstChild.nodeValue;
else
rule_port[i] ="";
if(Sel_proto[0].firstChild != null)
rule_proto[i] = Sel_proto[0].firstChild.nodeValue;
else
rule_proto[i] ="";
if(Sel_rate[0].firstChild != null)
rule_rate[i] = Sel_rate[0].firstChild.nodeValue;
else
rule_rate[i] ="";
if(Sel_prio[0].firstChild != null)
rule_prio[i] = Sel_prio[0].firstChild.nodeValue;
else
rule_prio[i] ="";
}
showQoSList();
}
function change_wizard(obj){
for(var j = 0; j < QoS_rules.length; j++){
if(rule_desc[j] != null && obj.value == j){
if(rule_proto[j] == "TCP")
document.form.qos_proto_x_0.options[0].selected = 1;
else if(rule_proto[j] == "UDP")
document.form.qos_proto_x_0.options[1].selected = 1;
else if(rule_proto[j] == "TCP/UDP")
document.form.qos_proto_x_0.options[2].selected = 1;
else if(rule_proto[j] == "ANY")
document.form.qos_proto_x_0.options[3].selected = 1;
else
document.form.qos_proto_x_0.options[0].selected = 1;
if(rule_prio[j] == "<#2317#>")
document.form.qos_prio_x_0.options[0].selected = 1;
else if(rule_prio[j] == "<#2316#>")
document.form.qos_prio_x_0.options[1].selected = 1;
else if(rule_prio[j] == "<#2690#>")
document.form.qos_prio_x_0.options[2].selected = 1;
else if(rule_prio[j] == "<#2666#>")
document.form.qos_prio_x_0.options[3].selected = 1;
else if(rule_prio[j] == "<#2667#>")
document.form.qos_prio_x_0.options[4].selected = 1;
else
document.form.qos_prio_x_0.options[2].selected = 1;
if(rule_rate[j] == ""){
document.form.qos_min_transferred_x_0.value = "";
document.form.qos_max_transferred_x_0.value = "";
}else{
var trans=rule_rate[j].split("~");
document.form.qos_min_transferred_x_0.value = trans[0];
document.form.qos_max_transferred_x_0.value = trans[1];
}
document.form.qos_service_name_x_0.value = rule_desc[j];
document.form.qos_port_x_0.value = rule_port[j];
break;
}
}
}
/*------------ Mouse event of fake LAN IP select menu {-----------------*/
function setClientIP(j){
document.form.qos_service_name_x_0.value = rule_desc[j];
if(rule_rate[j] == ""){
document.form.qos_min_transferred_x_0.value = "";
document.form.qos_max_transferred_x_0.value = "";
}
else{
var trans=rule_rate[j].split("~");
document.form.qos_min_transferred_x_0.value = trans[0];
document.form.qos_max_transferred_x_0.value = trans[1];
}
if(rule_proto[j] == "TCP")
document.form.qos_proto_x_0.options[0].selected = 1;
else if(rule_proto[j] == "UDP")
document.form.qos_proto_x_0.options[1].selected = 1;
else if(rule_proto[j] == "TCP/UDP")
document.form.qos_proto_x_0.options[2].selected = 1;
else if(rule_proto[j] == "ANY")
document.form.qos_proto_x_0.options[3].selected = 1;
/* marked By Viz 2011.12 for "iptables -p"
else if(rule_proto[j] == "ICMP")
document.form.qos_proto_x_0.options[3].selected = 1;
else if(rule_proto[j] == "IGMP")
document.form.qos_proto_x_0.options[4].selected = 1; */
else
document.form.qos_proto_x_0.options[0].selected = 1;
if(rule_prio[j] == "Highest")
document.form.qos_prio_x_0.options[0].selected = 1;
else if(rule_prio[j] == "High")
document.form.qos_prio_x_0.options[1].selected = 1;
else if(rule_prio[j] == "Medium")
document.form.qos_prio_x_0.options[2].selected = 1;
else if(rule_prio[j] == "Low")
document.form.qos_prio_x_0.options[3].selected = 1;
else if(rule_prio[j] == "Lowest")
document.form.qos_prio_x_0.options[4].selected = 1;
else
document.form.qos_prio_x_0.options[2].selected = 1;
document.form.qos_service_name_x_0.value = rule_desc[j];
document.form.qos_port_x_0.value = rule_port[j];
hideClients_Block();
}
function showQoSList(){
var code = "";
for(var i = 0; i < rule_desc.length; i++){
if(rule_port[i] == 0000)
code +='<a><div ><dt><strong>'+rule_desc[i]+'</strong></dt></div></a>';
else
code += '<a><div onclick="setClientIP('+i+');"><dd>'+rule_desc[i]+'</dd></div></a>';
}
code +='<!--[if lte IE 6.5]><iframe class="hackiframe2"></iframe><![endif]-->';
document.getElementById("QoSList_Block").innerHTML = code;
}
var isMenuopen = 0;
function pullQoSList(obj){
if(isMenuopen == 0){
obj.src = "/images/arrow-top.gif"
document.getElementById("QoSList_Block").style.display = 'block';
isMenuopen = 1;
}
else{
document.getElementById("pull_arrow").src = "/images/arrow-down.gif";
document.getElementById('QoSList_Block').style.display='none';
isMenuopen = 0;
}
}
function hideClients_Block(evt){
if(typeof(evt) != "undefined"){
if(!evt.srcElement)
evt.srcElement = evt.target; // for Firefox
if(evt.srcElement.id == "pull_arrow" || evt.srcElement.id == "QoSList_Block"){
return;
}
}
document.getElementById("pull_arrow").src = "/images/arrow-down.gif";
document.getElementById('QoSList_Block').style.display='none';
isMenuopen = 0;
}
/*----------} Mouse event of fake LAN IP select menu-----------------*/
function replace_symbol(){
var largre_src=new RegExp("^(>)([0-9]{1,5})$", "gi");
if(largre_src.test(document.form.qos_port_x_0.value)){
document.form.qos_port_x_0.value = document.form.qos_port_x_0.value.replace(/[>]/gi,""); // ">" to ""
document.form.qos_port_x_0.value = document.form.qos_port_x_0.value+":65535"; // add ":65535"
}
var smalre_src=new RegExp("^(<)([0-9]{1,5})$", "gi");
if(smalre_src.test(document.form.qos_port_x_0.value)){
document.form.qos_port_x_0.value = document.form.qos_port_x_0.value.replace(/[<]/gi,""); // "<" to ""
document.form.qos_port_x_0.value = "1:"+document.form.qos_port_x_0.value; // add "1:"
}
}
function pullLANIPList(obj){
var element = document.getElementById('ClientList_Block_PC');
var isMenuopen = element.offsetWidth > 0 || element.offsetHeight > 0;
if(isMenuopen == 0){
obj.src = "/images/arrow-top.gif"
element.style.display = 'block';
document.form.qos_ip_x_0.focus();
}
else
hideClients_Block_mac();
}
function hideClients_Block_mac(){
document.getElementById("pull_arrow_mac").src = "/images/arrow-down.gif";
document.getElementById('ClientList_Block_PC').style.display='none';
}
function setClientIP_mac(devname, macaddr){
document.form.qos_ip_x_0.value = macaddr;
if(document.form.qos_service_name_x_0.value.length == 0)
document.form.qos_service_name_x_0.value = devname;
hideClients_Block_mac();
}
function linkport(obj){
if(obj.value == "any"){
document.form.qos_port_x_0.value = "";
document.form.qos_port_x_0.disabled = true;
}else{
document.form.qos_port_x_0.disabled = false;
}
}
</script>
</head>
<body onkeydown="key_event(event);" onclick="if(isMenuopen){hideClients_Block(event)}" onLoad="initial();" onunLoad="return unload_body();" class="bg">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" id="ruleForm" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" name="current_page" value="Advanced_QOSUserRules_Content.asp">
<input type="hidden" name="next_page" value="">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="action_mode" value="apply">
<input type="hidden" name="action_wait" value="5">
<input type="hidden" name="action_script" value="restart_qos;restart_firewall">
<input type="hidden" name="first_time" value="">
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>">
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>">
<input type="hidden" name="qos_rulelist" value=''>
<table class="content" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
<div id="mainMenu"></div>
<div id="subMenu"></div>
</td>
<td valign="top">
<div id="tabMenu" class="submenuBlock"></div>
<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
<tr>
<td valign="top" >
<table width="760px" border="0" cellpadding="4" cellspacing="0" class="FormTitle" id="FormTitle">
<tr>
<td bgcolor="#4D595D" valign="top">
<table>
<tr>
<td>
<table width="100%" >
<tr >
<td class="formfonttitle" align="left">
<div id="content_title" style="margin-top:5px;"></div>
</td>
<td align="right" >
<div style="margin-top:5px;">
<select onchange="switchPage(this.options[this.selectedIndex].value)" class="input_option">
<!--option><#3326#></option-->
<option value="1"><#917#></option>
<option value="2" selected><#3063#></option>
<option value="3"><#3062#></option>
</select>
</div>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td height="5"><div class="splitLine"></div></td>
</tr>
<tr>
<td>
<div id="is_qos_enable_desc" class="formfontdesc" style="font-style: italic;font-size: 14px;color:#FFCC00;">
<ul>
<li><#3576#></li>
<li><#3577#></li>
</ul>
</div>
<div class="formfontdesc"><a id="faq" href="" style="text-decoration:underline;" target="_blank">QoS FAQ</a></div>
</div>
</td>
</tr>
<tr>
<td>
<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" class="FormTable_table" style="margin-top:8px">
<thead>
<tr>
<td colspan="4" id="TriggerList" style="border-right:none;"><#1525#>&nbsp;(<#2655#>&nbsp;32)</td>
<td colspan="3" id="TriggerList" style="border-left:none;">
<div style="margin-top:0px;display:none" align="right">
<select id='qos_default_sel' name='qos_default_sel' class="input_option" onchange="change_wizard(this);"></select>
</div>
</td>
</tr>
</thead>
<tr>
<th><#1526#></th>
<th><a href="javascript:void(0);" onClick="openHint(18,6);"><div class="table_text"><#1527#></div></a></th>
<th><a href="javascript:void(0);" onClick="openHint(18,4);"><div class="table_text"><#1528#></div></a></th>
<th><div class="table_text"><#2440#></div></th>
<th><a href="javascript:void(0);" onClick="openHint(18,5);"><div class="table_text"><div class="table_text"><#3574#></div></a></th>
<th><#1529#></th>
<th><#2654#></th>
</tr>
<tr>
<td width="20%">
<input type="text" maxlength="32" class="input_12_table" style="float:left;width:105px;" placeholder="<#742#>" name="qos_service_name_x_0" onKeyPress="return validator.isString(this, event)" autocorrect="off" autocapitalize="off">
<img id="pull_arrow" height="14px;" src="/images/arrow-down.gif" onclick="pullQoSList(this);" title="<#3163#>">
<div id="QoSList_Block" class="QoSList_Block" onclick="hideClients_Block()"></div>
</td>
<td width="20%">
<input type="text" maxlength="17" class="input_15_table" name="qos_ip_x_0" style="width:100px;float:left" autocorrect="off" autocapitalize="off">
<img id="pull_arrow_mac" class="pull_arrow"height="14px;" src="/images/arrow-down.gif" onclick="pullLANIPList(this);" title="<#3158#>">
<div id="ClientList_Block_PC" class="clientlist_dropdown" style="margin-left:2px;margin-top: 25px;"></div>
</td>
<td width="10%"><input type="text" maxlength="32" class="input_6_table" name="qos_port_x_0" onKeyPress="return validator.isPortRange(this, event)" autocorrect="off" autocapitalize="off"></td>
<td width="14%">
<select name="qos_proto_x_0" class="input_option" style="width:75px;" onChange="linkport(this);">
<option value="tcp">TCP</option>
<option value="udp">UDP</option>
<option value="tcp/udp" selected>TCP/UDP</option>
<option value="any">ANY</option>
</select>
</td>
<td width="15%">
<input type="text" class="input_3_table" maxlength="7" onKeyPress="return validator.isNumber(this,event);" onblur="conv_to_transf();" name="qos_min_transferred_x_0" autocorrect="off" autocapitalize="off">~
<input type="text" class="input_3_table" maxlength="7" onKeyPress="return validator.isNumber(this,event);" onblur="conv_to_transf();" name="qos_max_transferred_x_0" autocorrect="off" autocapitalize="off"> KB
<input type="hidden" name="qos_transferred_x_0" value="">
</td>
<td width="15%">
<select name='qos_prio_x_0' class="input_option" style="width:87px;"> <option value='0'><#2317#></option>
<option value='1' selected><#2316#></option>
<option value='2'><#2690#></option>
<option value='3'><#2666#></option>
<option value='4'><#2667#></option>
</select>
</td>
<td width="6%">
<input type="button" class="add_btn" onClick="addRow_Group(32);">
</td>
</tr>
</table>
<div id="qos_rulelist_Block"></div>
</td>
</tr>
<tr><td>
<div class="apply_gen">
<input name="button" type="button" class="button_gen" onClick="applyRule()" value="<#203#>"/>
</div>
</td></tr>
</table>
</td>
</tr>
</table>
</td>
</form>
</tr>
</table>
</td>
<td width="10" align="center" valign="top">&nbsp;</td>
</tr>
</table>
<div id="footer"></div>
</body>
</html>

