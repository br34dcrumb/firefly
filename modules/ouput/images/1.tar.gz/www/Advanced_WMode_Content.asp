﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html xmlns:v>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta HTTP-EQUIV="Expires" CONTENT="-1">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png">
<title><#860#> - <#399#></title>
<link rel="stylesheet" type="text/css" href="index_style.css">
<link rel="stylesheet" type="text/css" href="form_style.css">
<style>
#WDSAPList{
border:1px solid rgb(76,76,76);
background-color:rgb(55,55,55);
position:absolute;
margin-top:24px;
margin-left:220px;
*margin-left:-150px;
width:255px;
*width:259px;
text-align:left;
height:auto;
overflow-y:auto;
z-index:200;
padding: 1px;
display:none;
}
#WDSAPList div{
background-color:rgb(55,55,55);
height:20px;
line-height:20px;
text-decoration:none;
padding-left:2px;
}
#WDSAPList a{
background-color:#EFEFEF;
color:#FFF;
font-size:12px;
font-family:Arial, Helvetica, sans-serif;
text-decoration:none;
}
#WDSAPList div:hover {
background-color:#3366FF;
color:#FFFFFF;
cursor:default;
}
</style>
<script language="JavaScript" type="text/javascript" src="/state.js"></script>
<script type="text/javascript" language="JavaScript" src="/help.js"></script>
<script language="JavaScript" type="text/javascript" src="/general.js"></script>
<script language="JavaScript" type="text/javascript" src="/popup.js"></script>
<script language="JavaScript" type="text/javascript" src="/validator.js"></script>
<script language="JavaScript" type="text/JavaScript" src="/js/jquery.js"></script>
<script language="JavaScript" type="text/JavaScript" src="/js/httpApi.js"></script>
<script>
<% wl_get_parameter(); %>
var wl_wdslist_array = '<% nvram_get("wl_wdslist"); %>';
var wds_aplist = "";
var faq_href = "https://nw-dlcdnet.asus.com/support/forward.html?model=&type=Faq&lang="+ui_lang+"&kw=&num=128";
function initial(){
show_menu();
regen_band(document.form.wl_unit);
if(lantiq_support){
checkWLReady();
var mode_desc = ["<#3958#>"];
var mode_value = ["2"];
add_options_x2(document.form.wl_mode_x, mode_desc, mode_value, "2");
}
if(based_modelid == "RT-AC87U" && document.form.wl_unit[1].selected == true){
document.getElementById("wds_mode_field").style.display = "none";
document.form.wl_mode_x.value="2";
}
change_wireless_bridge(document.form.wl_mode_x.value);
if((sw_mode == 2 || sw_mode == 4) && '<% nvram_get("wl_unit"); %>' == '<% nvram_get("wlc_band"); %>'){
for(var i=5; i>=3; i--)
document.getElementById("MainTable1").deleteRow(i);
for(var i=2; i>=0; i--)
document.getElementById("MainTable2").deleteRow(i);
document.getElementById("repeaterModeHint").style.display = "";
document.getElementById("wl_wdslist_Block").style.display = "none";
document.getElementById("submitBtn").style.display = "none";
}
else if (band60g_support && '<% nvram_get("wl_unit"); %>' == '3') {
document.getElementById("wl_2g_mac").style.display = "none";
document.getElementById("wl_5g_mac").style.display = "none";
document.getElementById("wl_5g_mac_2").style.display = "none";
document.getElementById("wds_mode_field").style.display = "none";
document.getElementById("wds_wdsapply_field").style.display = "none";
document.getElementById("wl_wdslist_Block").style.display = "none";
document.getElementById("submitBtn").style.display = "none";
document.getElementById("wds_list_title_field").style.display = "none";
document.getElementById("wds_list_add_delete_field").style.display = "none";
document.getElementById("wds_list_add_field").style.display = "none";
document.getElementById("repeaterModeHint_desc").innerHTML = "<#1685#>";
document.getElementById("repeaterModeHint").style.display = "";
}
else{
show_wl_wdslist();
}
if(!band5g_support){
document.getElementById("wl_5g_mac").style.display = "none";
document.getElementById("wl_unit_field").style.display = "none";
}
if(wl_info.band5g_2_support || wl_info.band6g_support){
if(band6g_support){
document.getElementById("5g2_title").innerHTML = "6 GHz MAC";
}
document.getElementById("wl_5g_mac_2").style.display = "";
document.getElementById("wl_5g_mac_th1").innerHTML = "5 GHz-1 MAC";
}
$("#redirect_to_setup")
.attr('target','_self')
.attr("href", "Advanced_Wireless_Content.asp")
.attr("style", "text-decoration:underline;color:#FFCC00;");
$("#redirect_to_FAQ")
.attr('target','_blank')
.attr("style", "text-decoration:underline;color:#FFCC00;cursor: pointer;");
document.getElementById("redirect_to_FAQ").href=faq_href;
wl_bwch_hint();
setTimeout("wds_scan();", 500);
}
function show_wl_wdslist(){
var wl_wdslist_row = wl_wdslist_array.split('&#60');
var code = "";
code +='<table width="100%" border="1" cellspacing="0" cellpadding="4" align="center" class="list_table" id="wl_wdslist_table">';
if(wl_wdslist_row.length == 1){
code +='<tr><td style="color:#FFCC00;"><#2447#></td>';
}
else{
for(var i = 1; i < wl_wdslist_row.length; i++){
code +='<tr id="row'+i+'">';
code +='<td width="80%">'+ wl_wdslist_row[i] +'</td>';
code +='<td width="20%"><input type="button" class=\"remove_btn\" onclick=\"deleteRow(this);\" value=\"\"/></td></tr>';
}
}
code +='</tr></table>';
document.getElementById("wl_wdslist_Block").innerHTML = code;
}
function deleteRow(r){
var i=r.parentNode.parentNode.rowIndex;
document.getElementById('wl_wdslist_table').deleteRow(i);
var wl_wdslist_value = "";
for(i=0; i< document.getElementById('wl_wdslist_table').rows.length; i++){
wl_wdslist_value += "&#60";
wl_wdslist_value += document.getElementById('wl_wdslist_table').rows[i].cells[0].innerHTML;
}
wl_wdslist_array = wl_wdslist_value;
if(wl_wdslist_array == "")
show_wl_wdslist();
}
function addRow(obj, upper){
var rule_num = document.getElementById('wl_wdslist_table').rows.length;
var item_num = document.getElementById('wl_wdslist_table').rows[0].cells.length;
if(rule_num >= upper){
alert("<#2523#> " + upper + " <#2524#>");
return false;
}
if(obj.value==""){
alert("<#332#>");
obj.focus();
obj.select();
return false;
}else if (!check_macaddr(obj, check_hwaddr_flag(obj, 'inner'))){
obj.focus();
obj.select();
return false;
}
for(i=0; i<rule_num; i++){
for(j=0; j<item_num-1; j++){
if(obj.value.toLowerCase() == document.getElementById('wl_wdslist_table').rows[i].cells[j].innerHTML.toLowerCase()){
alert("<#2516#>");
return false;
}
}
}
wl_wdslist_array += "&#60";
wl_wdslist_array += obj.value;
obj.value = "";
show_wl_wdslist();
}
function applyRule(){
if(lantiq_support && wave_ready != 1){
alert("Please wait a minute for wireless ready");
return false;
}
var rule_num = document.getElementById('wl_wdslist_table').rows.length;
var item_num = document.getElementById('wl_wdslist_table').rows[0].cells.length;
var tmp_value = "";
for(i=0; i<rule_num; i++){
tmp_value += "<"
for(j=0; j<item_num-1; j++){
tmp_value += document.getElementById('wl_wdslist_table').rows[i].cells[j].innerHTML;
if(j != item_num-2)
tmp_value += ">";
}
}
if(tmp_value == "<"+"<#2447#>" || tmp_value == "<"){
tmp_value = "";
}
document.form.wl_wdslist.value = tmp_value;
if(document.form.wl_mode_x.value == "0"){
inputRCtrl1(document.form.wl_wdsapply_x, 1);
inputRCtrl2(document.form.wl_wdsapply_x, 1);
}
if(wl6_support){
document.form.action_wait.value = 8;
}
else{
document.form.action_wait.value = 3;
}
showLoading();
document.form.submit();
}
function done_validating(action){
refreshpage();
}
/*------------ Site Survey Start -----------------*/
function wds_scan(){
var ajaxURL = '/wds_aplist_2g.asp';
if('<% nvram_get("wl_unit"); %>' == '1')
var ajaxURL = '/wds_aplist_5g.asp';
else if('<% nvram_get("wl_unit"); %>' == '2')
var ajaxURL = '/wds_aplist_5g_2.asp';
$.ajax({
url: ajaxURL,
dataType: 'script',
error: function(xhr){
setTimeout("wds_scan();", 1000);
},
success: function(response){
showLANIPList();
}
});
}
function setClientIP(num){
document.form.wl_wdslist_0.value = wds_aplist[num][1];
hideClients_Block();
over_var = 0;
}
function rescan(){
wds_aplist = "";
showLANIPList()
wds_scan();
}
function showLANIPList(){
var code = "";
var show_name = "";
var show_title = "";
if(wds_aplist != ""){
for(var i = 0; i < wds_aplist.length ; i++){
wds_aplist[i][0] = htmlEnDeCode.htmlEncode(decodeURIComponent(wds_aplist[i][0]));
if(wds_aplist[i][0] && wds_aplist[i][0].length > 12)
show_name = wds_aplist[i][0].substring(0, 10) + "...";
else
show_name = wds_aplist[i][0];
show_title = wds_aplist[i][0];
if(wds_aplist[i][1]){
code += '<a><div onmouseover="over_var=1;" onmouseout="over_var=0;" onclick="setClientIP('+i+');" title="'+show_title+'"><strong>'+show_name+'</strong>';
if(show_name && show_name.length > 0)
code += '( '+wds_aplist[i][1]+')';
else
code += wds_aplist[i][1];
code += ' </div></a>';
}
}
code += '<div style="text-decoration:underline;font-weight:bolder;" onclick="rescan();"><#1419#></div>';
}
else{
code += '<div style="width:98px"><img height="15px" style="margin-left:5px;margin-top:2px;" src="/images/InternetScan.gif"></div>';
}
code +='<!--[if lte IE 6.5]><iframe class="hackiframe2"></iframe><![endif]-->';
document.getElementById("WDSAPList").innerHTML = code;
}
function pullLANIPList(obj){
if(isMenuopen == 0){
obj.src = "/images/arrow-top.gif"
document.getElementById("WDSAPList").style.display = 'block';
document.form.wl_wdslist_0.focus();
isMenuopen = 1;
}
else
hideClients_Block();
}
var over_var = 0;
var isMenuopen = 0;
function hideClients_Block(){
document.getElementById("pull_arrow").src = "/images/arrow-down.gif";
document.getElementById('WDSAPList').style.display='none';
isMenuopen = 0;
}
function check_macaddr(obj,flag){ //control hint of input mac address
if(flag == 1){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<br><br><#364#>";
document.getElementById("check_mac").style.display = "";
return false;
}else if(flag == 2){
var childsel=document.createElement("div");
childsel.setAttribute("id","check_mac");
childsel.style.color="#FFCC00";
obj.parentNode.appendChild(childsel);
document.getElementById("check_mac").innerHTML="<br><br><#325#>";
document.getElementById("check_mac").style.display = "";
return false;
}else{
document.getElementById("check_mac") ? document.getElementById("check_mac").style.display="none" : true;
return true;
}
}
/*---------- Site Survey End -----------------*/
/* Control display chanspec hint when wl_bw=0(20/40/80) or wl_chanspec=0(Auto) */
function wl_bwch_hint(){
if(wl6_support){
document.getElementById("wl_bw_hint").style.display=(document.form.wl_bw.value == "0") ? "" : "none";
document.getElementById("wl_ch_hint").style.display=(document.form.wl_chanspec.value == "0") ? "" : "none";
}
else{
document.getElementById("wl_bw_hint").style.display=(document.form.wl_bw.value == "1") ? "" : "none";
document.getElementById("wl_ch_hint").style.display=(document.form.wl_channel.value == "0") ? "" : "none";
}
}
function checkWLReady(){
$.ajax({
url: '/ajax_wl_ready.asp',
dataType: 'script',
error: function(xhr) {
setTimeout("checkWLReady();", 1000);
},
success: function(response){
if(wave_ready != 1){
$("#lantiq_ready").show();
setTimeout("checkWLReady();", 1000);
}
else{
$("#lantiq_ready").hide();
}
}
});
}
</script>
</head>
<body onload="initial();" onunLoad="return unload_body();" class="bg">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" value="<% nvram_get("productid"); %>" name="productid" >
<input type="hidden" name="current_page" value="Advanced_WMode_Content.asp">
<input type="hidden" name="next_page" value="Advanced_WMode_Content.asp">
<input type="hidden" name="group_id" value="wl_wdslist">
<input type="hidden" name="modified" value="0">
<input type="hidden" name="action_mode" value="apply_new">
<input type="hidden" name="action_wait" value="8">
<input type="hidden" name="first_time" value="">
<input type="hidden" name="action_script" value="restart_wireless">
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>">
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>">
<input type="hidden" maxlength="15" size="15" name="x_RegulatoryDomain" value="<% nvram_get("x_RegulatoryDomain"); %>" readonly="1">
<input type="hidden" name="wl_wdsnum_x_0" value="<% nvram_get("wl_wdsnum_x"); %>" readonly="1">
<input type="hidden" name="wl_nmode_x" value='<% nvram_get("wl_nmode_x"); %>'>
<input type="hidden" name="wl_bw" value='<% nvram_get("wl_bw"); %>'>
<input type="hidden" name="wl_channel" value='<% nvram_get("wl_channel"); %>'>
<input type="hidden" name="wl_chanspec" value='<% nvram_get("wl_chanspec"); %>'>
<input type="hidden" name="wl_nctrlsb_old" value='<% nvram_get("wl_nctrlsb"); %>'>
<input type="hidden" name="wl_wdslist" value=''>
<input type="hidden" name="wl_subunit" value="-1">
<table class="content" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
<div id="mainMenu"></div>
<div id="subMenu"></div>
</td>
<td valign="top">
<div id="tabMenu" class="submenuBlock"></div>
<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
<tr>
<td align="left" valign="top" >
<table width="760px" border="0" cellpadding="4" cellspacing="0" class="FormTitle" id="FormTitle">
<tbody>
<tr>
<td bgcolor="#4D595D" valign="top">
<div>&nbsp;</div>
<div class="formfonttitle"><#396#> - <#399#></div>
<div style="margin:10px 0 10px 5px;" class="splitLine"></div>
<div class="formfontdesc"><#3897#></div>
<div class="formfontdesc hint-color"><#939#></div>
<div class="formfontdesc hint-color" style="margin-left:28px;">
<#3898#>&nbsp;<#3899#><br><#3193#>
</div>
<div class="formfontdesc"><#3900#>
<ol>
<li><#3901#></li>
<li><#3902#></li>
<li><#3903#></li>
<li><#3904#></li>
</ol>
</div>
<div id="wl_bw_hint" class="hint-color" style="font-size:13px;margin-left:28px;"><#3905#></div>
<div id="wl_ch_hint" class="hint-color" style="font-size:13px;margin-left:28px;"><#3906#></div>
<div id="lantiq_ready" style="display:none;margin-left:5px;font-size:13px;">Wireless is setting...</div>
<table id="MainTable1" width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
<thead>
<tr>
<td colspan="2"><#3350#></td>
</tr>
</thead>
<tr id="wl_2g_mac">
<th>2.4 GHz MAC</th>
<td>
<input type="text" maxlength="17" class="input_20_table" id="wl0_hwaddr" name="wl0_hwaddr" value="<% nvram_get("wl0_hwaddr"); %>" readonly autocorrect="off" autocapitalize="off">
</td>
</tr>
<tr id="wl_5g_mac">
<th id="wl_5g_mac_th1">5 GHz MAC</th>
<td>
<input type="text" maxlength="17" class="input_20_table" id="wl1_hwaddr" name="wl1_hwaddr" value="<% nvram_get("wl1_hwaddr"); %>" readonly autocorrect="off" autocapitalize="off">
</td>
</tr>
<tr id="wl_5g_mac_2" style="display:none">
<th id="5g2_title">5 GHz-2 MAC</th>
<td>
<input type="text" maxlength="17" class="input_20_table" id="wl2_hwaddr" name="wl2_hwaddr" value="<% nvram_get("wl2_hwaddr"); %>" readonly autocorrect="off" autocapitalize="off">
</td>
</tr>
<tr id="wl_unit_field">
<th><#2364#></th>
<td>
<select name="wl_unit" class="input_option" onChange="change_wl_unit();"></select>
</td>
</tr>
<tr id="repeaterModeHint" style="display:none;">
<td id="repeaterModeHint_desc" colspan="2" class="hint-color" style="height:30px;" align="center"><#481#></td>
</tr>
<tr id="wds_mode_field">
<th align="right">
<a class="hintstyle" href="javascript:void(0);" onClick="openHint(1,1);">
<#3955#></a>
</th>
<td>
<select name="wl_mode_x" class="input_option" onChange="change_wireless_bridge(this.value);">
<option value="0" <% nvram_match("wl_mode_x", "0","selected"); %>><#3956#></option>
<option value="1" <% nvram_match("wl_mode_x", "1","selected"); %>><#3957#></option>
<option value="2" <% nvram_match("wl_mode_x", "2","selected"); %>><#3958#></option>
</select>
</td>
</tr>
<tr id=wds_wdsapply_field>
<th align="right">
<a class="hintstyle" href="javascript:void(0);" onClick="openHint(1,3);">
<#3972#>
</a>
</th>
<td>
<input type="radio" value="1" name="wl_wdsapply_x" class="input" <% nvram_match("wl_wdsapply_x", "1", "checked"); %>><#194#>
<input type="radio" value="0" name="wl_wdsapply_x" class="input" <% nvram_match("wl_wdsapply_x", "0", "checked"); %>><#193#>
</td>
</tr>
</table>
<table id="MainTable2" width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable_table">
<thead>
<tr id="wds_list_title_field">
<td colspan="4"><#3925#>&nbsp;(<#2655#>&nbsp;4)</td>
</tr>
</thead>
<tr id="wds_list_add_delete_field">
<th width="80%"><a class="hintstyle" href="javascript:void(0);" onClick="openHint(5,10);"><#3925#></th>
<th class="edit_table" width="20%"><#2654#></th>
</tr>
<tr id="wds_list_add_field">
<td width="80%">
<input type="text" style="margin-left:220px;float:left;" maxlength="17" class="input_macaddr_table" name="wl_wdslist_0" onKeyPress="return validator.isHWAddr(this,event)" autocorrect="off" autocapitalize="off">
<img style="float:left;" id="pull_arrow" height="14px;" src="/images/arrow-down.gif" onclick="pullLANIPList(this);" title="<#3156#>" onmouseover="over_var=1;" onmouseout="over_var=0;">
<div id="WDSAPList" class="WDSAPList">
<div style="width:98px">
<img height="15px" style="margin-left:5px;margin-top:2px;" src="/images/InternetScan.gif">
</div>
</div>
</td>
<td width="20%">
<input type="button" class="add_btn" onClick="addRow(document.form.wl_wdslist_0, 4);" value="">
</td>
</tr>
</table>
<div id="wl_wdslist_Block"></div>
<div class="apply_gen">
<input class="button_gen" id="submitBtn" onclick="applyRule()" type="button" value="<#203#>" />
</div>
</td>
</tr>
</tbody>
</table>
</td>
</form>
</tr>
</table>
</td>
<td width="10" align="center" valign="top">&nbsp;</td>
</tr>
</table>
<div id="footer"></div>
</body>
</html>

